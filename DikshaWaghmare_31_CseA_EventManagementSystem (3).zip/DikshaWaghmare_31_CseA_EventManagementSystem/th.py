import os
import subprocess

def compress_with_7zip(input_folder, output_file):
    """
    Compresses the given folder using 7z format with max compression.
    """
    if not os.path.exists(input_folder):
        print("Input folder not found.")
        return

    command = [
        "7z", "a",                     # 'a' = add to archive
        "-t7z",                        # 7z archive format
        "-mx=9",                       # Maximum compression
        output_file,                  # Output archive
        input_folder                  # Input folder or file
    ]

    try:
        subprocess.run(command, check=True)
        print(f"Compressed successfully to {output_file}")
    except subprocess.CalledProcessError as e:
        print("Compression failed:", e)

# Example usage
compress_with_7zip(
    r"C:\Users\diksh\OneDrive\Desktop\DikshaWaghmare_31_CseA_EventManagementSystem",
    "compressed_output.7z"
)
