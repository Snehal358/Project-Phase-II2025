from flask import Flask, render_template, request, redirect, url_for, session, flash, g, Response,make_response, get_flashed_messages,send_file
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
import csv
from io import StringIO
import os
from werkzeug.utils import secure_filename
from datetime import datetime, timedelta
import smtplib
import json
from utils.email_utils import get_wedding_booking_by_id, get_guests_for_booking, send_email, generate_wedding_plan_pdf, send_reset_email, send_ticket_cancel_email
from utils.auth_utils import get_user_by_email, update_user_password, generate_reset_token, verify_token, verify_password
import io  
from flask_mail import Message
# from flask_mail import Mail
import uuid
from flask_apscheduler import APScheduler
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
    # ✅ Process and group vendors per event
from collections import defaultdict
from urllib.parse import unquote_plus
import urllib.parse
import requests
from flask import g
import pdfkit
from PIL import Image, ImageDraw, ImageFont
import tempfile
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from flask import send_file
from io import BytesIO
from xhtml2pdf import pisa
from flask import render_template_string
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet


app = Flask(__name__)
app.secret_key = 'your_secret_key'

DATABASE = 'database.db'

# ---------- DATABASE CONNECTION ----------
def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

# ---------- ROUTES ----------
@app.route('/')
def index():
    db = get_db()
    # Query for events in each category
    tech_events = db.execute("SELECT * FROM events WHERE category = 'Tech' AND is_deleted = 0").fetchall()
    art_events = db.execute("SELECT * FROM events WHERE category = 'Art' AND is_deleted = 0").fetchall()
    fitness_events = db.execute("SELECT * FROM events WHERE category = 'Fitness' AND is_deleted = 0").fetchall()
    culture_events = db.execute("SELECT * FROM events WHERE category = 'Culture' AND is_deleted = 0").fetchall()

    # 1. Admin-marked popular events
    manual_popular = db.execute('''
        SELECT * FROM events
        WHERE is_popular = 1 AND is_deleted = 0
    ''').fetchall()

    # 2. Most booked events
    dynamic_popular = db.execute('''
        SELECT events.*, COUNT(bookings.id) AS booking_count
        FROM events
        LEFT JOIN bookings ON events.id = bookings.event_id
        WHERE events.is_deleted = 0
        GROUP BY events.id
        ORDER BY booking_count DESC
        LIMIT 4
    ''').fetchall()

    # 3. Merge both — ensuring uniqueness by ID
    popular_dict = {}
    for event in manual_popular:
        popular_dict[event['id']] = dict(event)
        popular_dict[event['id']]['is_popular'] = 1  # Editor Pick

    for event in dynamic_popular:
        if event['id'] not in popular_dict:
            popular_dict[event['id']] = dict(event)
        popular_dict[event['id']]['booking_count'] = event['booking_count']

    combined_popular = list(popular_dict.values())

    return render_template('index.html', 
                           tech_events=tech_events, 
                           art_events=art_events, 
                           fitness_events=fitness_events, 
                           culture_events=culture_events,
                           combined_popular=combined_popular)


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = generate_password_hash(request.form['password'])

        db = get_db()
        try:
            db.execute("INSERT INTO users (username, email, password) VALUES (?, ?, ?)",
                       (username, email, password))
            db.commit()
            flash("Signup successful. Please login.")
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash("Email already exists.")
            return redirect(url_for('signup'))

    return render_template('signup.html')



@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        user = get_user_by_email(email)

        if user and verify_password(user['password'], password):
            session['user_id'] = user['id']
            session['username'] = user['username']
            flash("Login successful.")
            return redirect(url_for('index'))
        else:
            flash("Invalid email or password.")
            return redirect(url_for('login'))

    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    flash("Logged out successfully.")
    return redirect(url_for('index'))


def book_event(event_id):
    if 'user_id' not in session:
        flash('You must be logged in to book an event.')
        return redirect(url_for('login'))

    return redirect(url_for('start_booking', event_id=event_id))


@app.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form['email']
        user = get_user_by_email(email)
        if user:
            token = generate_reset_token(user['id'])
            reset_url = url_for('reset_password', token=token, _external=True)
            send_reset_email(user['email'], reset_url)
            print(f"🔗 Reset link: {reset_url}")  # Replace with real email latera
            flash("📧 A reset link has been sent to your email.")
        else:
            flash("❌ No account found with that email.")
    return render_template('forgot_password.html')

@app.route('/reset-password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    user_id = verify_token(token)
    if not user_id:
        flash("⛔ Token is invalid or expired.")
        return redirect(url_for('forgot_password'))

    if request.method == 'POST':
        new_password = request.form['password']
        update_user_password(user_id, new_password)
        flash("✅ Your password has been reset. Please log in.")
        return redirect(url_for('login'))

    return render_template('reset_password.html')



# @app.route('/profile')
# def profile():
#     if 'user_id' not in session:
#         flash("Please login first.")
#         return redirect(url_for('login'))

#     db = get_db()
    
#     # Fetch logged-in user's basic details
#     user = db.execute("SELECT * FROM users WHERE id = ?", (session['user_id'],)).fetchone()

#     # Regular event bookings
#     bookings = db.execute("""
#         SELECT events.id AS event_id, events.title, events.start_date, events.end_date,
#             events.location, events.event_date, bookings.booking_date, bookings.ticket_quantity
#         FROM bookings
#         JOIN events ON bookings.event_id = events.id
#         WHERE bookings.user_id = ?
#         ORDER BY bookings.booking_date DESC
#     """, (session['user_id'],)).fetchall()


#     # Wedding bookings including status
#     wedding_bookings = db.execute("""
#         SELECT wb.id, wt.name AS theme, wb.booking_date, wb.guest_count, wb.booked_on, wb.status
#         FROM wedding_bookings wb
#         JOIN wedding_themes wt ON wb.theme_id = wt.id
#         WHERE wb.user_id = ?
#     """, (session['user_id'],)).fetchall()

#     # Fetch guest list for each wedding booking
#     guest_lists = {}
#     for booking in wedding_bookings:
#         guests = db.execute("""
#             SELECT guest_name, guest_email, rsvp_status
#             FROM wedding_guests
#             WHERE booking_id = ?
#         """, (booking['id'],)).fetchall()
#         guest_lists[booking['id']] = guests

#     return render_template(
#         'profile.html',
#         user=user,
#         bookings=bookings,
#         wedding_bookings=wedding_bookings,
#         guest_lists=guest_lists
#     )

@app.route('/profile')
def profile():
    if 'user_id' not in session:
        flash("Please login first.")
        return redirect(url_for('login'))

    db = get_db()

    # Fetch user info
    user = db.execute("SELECT * FROM users WHERE id = ?", (session['user_id'],)).fetchone()

    # Event bookings with status and ticket quantity
    bookings = db.execute("""
        SELECT bookings.id AS booking_id, events.id AS event_id,
               events.title, events.start_date, events.end_date, events.location,
               events.event_date, bookings.booking_date, bookings.ticket_quantity, bookings.status
        FROM bookings
        JOIN events ON bookings.event_id = events.id
        WHERE bookings.user_id = ?
        ORDER BY bookings.booking_date DESC
    """, (session['user_id'],)).fetchall()

    # Wedding bookings (same as before)
    wedding_bookings = db.execute("""
        SELECT wb.id, wt.name AS theme, wb.booking_date, wb.guest_count, wb.booked_on, wb.status
        FROM wedding_bookings wb
        JOIN wedding_themes wt ON wb.theme_id = wt.id
        WHERE wb.user_id = ?
    """, (session['user_id'],)).fetchall()

    # Guest list for weddings
    guest_lists = {}
    for booking in wedding_bookings:
        guests = db.execute("""
            SELECT guest_name, guest_email, rsvp_status
            FROM wedding_guests
            WHERE booking_id = ?
        """, (booking['id'],)).fetchall()
        guest_lists[booking['id']] = guests

    return render_template(
        'profile.html',
        user=user,
        bookings=bookings,
        wedding_bookings=wedding_bookings,
        guest_lists=guest_lists
    )

# @app.route('/cancel_tickets/<int:booking_id>', methods=['GET', 'POST'])
# def cancel_tickets(booking_id):
#     if 'user_id' not in session:
#         flash("Please log in first.")
#         return redirect(url_for('login'))

#     db = get_db()

#     # Join with events table to fetch event title
#     booking = db.execute("""
#         SELECT b.*, e.title AS event_title
#         FROM bookings b
#         JOIN events e ON b.event_id = e.id
#         WHERE b.id = ? AND b.user_id = ?
#     """, (booking_id, session['user_id'])).fetchone()

#     # Handle invalid or already cancelled bookings
#     if not booking or booking['status'] != 'active':
#         flash("Booking not found or already canceled.")
#         return redirect(url_for('profile'))

#     if request.method == 'POST':
#         try:
#             cancel_qty = int(request.form['cancel_quantity'])
#         except ValueError:
#             flash("Please enter a valid number.")
#             return redirect(request.url)

#         if cancel_qty <= 0 or cancel_qty > booking['ticket_quantity']:
#             flash("Invalid number of tickets to cancel.")
#             return redirect(request.url)

#         remaining = booking['ticket_quantity'] - cancel_qty

#         if remaining == 0:
#             # Full cancellation
#             db.execute("UPDATE bookings SET ticket_quantity = 0, status = 'cancelled' WHERE id = ?", (booking_id,))
#             flash("Booking fully canceled.")
#         else:
#             # Partial cancellation
#             db.execute("UPDATE bookings SET ticket_quantity = ? WHERE id = ?", (remaining, booking_id))
#             flash(f"{cancel_qty} ticket(s) canceled. {remaining} ticket(s) remain.")

#         db.commit()
#         return redirect(url_for('profile'))

#     return render_template('cancel_tickets.html', booking=booking)

@app.route('/cancel_tickets/<int:booking_id>', methods=['GET', 'POST'])
def cancel_tickets(booking_id):
    if 'user_id' not in session:
        flash("Please log in first.")
        return redirect(url_for('login'))

    db = get_db()

    # Fetch booking with event info
    booking = db.execute("""
        SELECT b.*, e.title AS event_title, u.username, u.email
        FROM bookings b
        JOIN events e ON b.event_id = e.id
        JOIN users u ON b.user_id = u.id
        WHERE b.id = ? AND b.user_id = ?
    """, (booking_id, session['user_id'])).fetchone()

    if not booking or booking['status'] != 'active':
        flash("Booking not found or already canceled.")
        return redirect(url_for('profile'))

    if request.method == 'POST':
        try:
            cancel_qty = int(request.form['cancel_quantity'])
        except ValueError:
            flash("Please enter a valid number.")
            return redirect(request.url)

        if cancel_qty <= 0 or cancel_qty > booking['ticket_quantity']:
            flash("Invalid number of tickets to cancel.")
            return redirect(request.url)

        remaining = booking['ticket_quantity'] - cancel_qty

        if remaining == 0:
            # Full cancellation
            db.execute("UPDATE bookings SET ticket_quantity = 0, status = 'cancelled' WHERE id = ?", (booking_id,))
            db.execute("UPDATE events SET available_tickets = available_tickets + ? WHERE id = ?", (cancel_qty, booking['event_id']))
            db.commit()

            flash("Booking fully canceled.")
            send_ticket_cancel_email(
                recipient=booking['email'],
                username=booking['username'],
                event_title=booking['event_title'],
                cancelled=cancel_qty,
                remaining=0,
                full_cancel=True
            )
        else:
            # Partial cancellation
            db.execute("UPDATE bookings SET ticket_quantity = ? WHERE id = ?", (remaining, booking_id))
            db.execute("UPDATE events SET available_tickets = available_tickets + ? WHERE id = ?", (cancel_qty, booking['event_id']))
            db.commit()

            flash(f"{cancel_qty} ticket(s) canceled. {remaining} ticket(s) remain.")
            send_ticket_cancel_email(
                recipient=booking['email'],
                username=booking['username'],
                event_title=booking['event_title'],
                cancelled=cancel_qty,
                remaining=remaining,
                full_cancel=False
            )

        return redirect(url_for('profile'))

    return render_template('cancel_tickets.html', booking=booking)


@app.route('/admin/bookings', methods=['GET', 'POST'])
def admin_bookings():
    if 'user_id' not in session or session.get('username') != 'admin':
        flash("Admin access only.")
        return redirect(url_for('login'))

    db = get_db()

    
    query = """
        SELECT users.username, users.email, events.title AS event_title,
               events.start_date, events.end_date, events.location, events.event_date, bookings.booking_date, bookings.ticket_quantity, bookings.original_ticket_quantity, bookings.status
        FROM bookings
        JOIN users ON bookings.user_id = users.id
        JOIN events ON bookings.event_id = events.id
    """
    filters = []
    params = []

    # Check if filter is applied
    if request.method == 'POST':
        start_date = request.form.get('start_date')
        end_date = request.form.get('end_date')

        if start_date:
            filters.append("DATE(booking_date) >= ?")
            params.append(start_date)
        if end_date:
            filters.append("DATE(booking_date) <= ?")
            params.append(end_date)

    if filters:
        query += " WHERE " + " AND ".join(filters)

    query += " ORDER BY bookings.booking_date DESC"

    bookings = db.execute(query, params).fetchall()

    return render_template('admin_bookings.html', bookings=bookings)


@app.route('/admin/export_csv')
def export_bookings_csv():
    if 'user_id' not in session or session.get('username') != 'admin':
        flash("Admin access only.")
        return redirect(url_for('login'))

    db = get_db()
    bookings = db.execute("""
        SELECT users.username, users.email, events.title AS event_title,
               events.start_date, events.end_date, events.location, bookings.booking_date
        FROM bookings
        JOIN users ON bookings.user_id = users.id
        JOIN events ON bookings.event_id = events.id
        ORDER BY bookings.booking_date DESC
    """).fetchall()

    output = StringIO()
    writer = csv.writer(output)

    # Write CSV header
    writer.writerow(['Username', 'Email', 'Event', 'Start Date', 'End Date', 'Location', 'Booking Date'])

    # Write data rows
    for b in bookings:
        writer.writerow([
            b['username'], b['email'], b['event_title'],
            b['start_date'], b['end_date'], b['location'],
            b['booking_date']
        ])

    output.seek(0)

    return Response(output,
                    mimetype="text/csv",
                    headers={"Content-Disposition": "attachment;filename=bookings.csv"})



@app.route('/upload_event', methods=['POST'])
def upload_event():
    image = request.files['image']
    filename = image.filename
    image.save(os.path.join('static/images', filename))
    # Save filename in DB or event.image = filename

UPLOAD_FOLDER = 'static/images'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'webp'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/admin/add_event', methods=['GET', 'POST'])
def add_event():
    if 'user_id' not in session or session.get('username') != 'admin':
        flash("Admin access only.")
        return redirect(url_for('login'))

    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        start_date = request.form['start_date']
        end_date = request.form['end_date']
        location = request.form['location']
        category = request.form['category']  # Get the category from the form
        capacity = request.form['capacity']
        price = request.form['price']
        time = request.form['time']
        event_date = request.form['event_date'] 
        try:
            capacity = int(request.form['capacity'])
            price = float(request.form['price'])
            available_tickets = int(request.form.get('available_tickets') or capacity)
        except ValueError:
            flash("Invalid numeric input.")
            return redirect(url_for('add_event'))
        
        is_popular = 1 if request.form.get('is_popular') == 'on' else 0

        
        # # Convert date strings to datetime objects
        # start_date_obj = datetime.strptime(start_date, '%Y-%m-%d')
        # end_date_obj = datetime.strptime(end_date, '%Y-%m-%d')

                # Convert date strings to datetime objects
        try:
            start_date_obj = datetime.strptime(start_date, '%Y-%m-%d')
            end_date_obj = datetime.strptime(end_date, '%Y-%m-%d')
            event_date_obj = datetime.strptime(event_date, '%Y-%m-%d')
        except ValueError:
            flash("Invalid date format. Use YYYY-MM-DD.")
            return redirect(url_for('add_event'))

        # Ensure the start date is today or a future date
        if start_date_obj < datetime.now():
            flash("Start date cannot be in the past.")
            return redirect(url_for('add_event'))

        # Ensure the end date is after the start date
        if end_date_obj <= start_date_obj:
            flash("End date must be after the start date.")
            return redirect(url_for('add_event'))
        
        if not (event_date_obj > start_date_obj and event_date_obj > end_date_obj):
            flash("Event date must be after both start and end dates.")
            return redirect(url_for('add_event'))
        
        
        image = request.files['image']
        if image and allowed_file(image.filename):
            filename = secure_filename(image.filename)
            image_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            image.save(image_path)
        else:
            flash('Invalid image format')
            return redirect(request.url)

        db = get_db()
        db.execute("INSERT INTO events (title, description, start_date, end_date, location, category, image, capacity, price, time, archived, available_tickets, is_popular, event_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ",
                   (title, description, start_date, end_date, location, category, filename, capacity, price, time, 0, available_tickets, is_popular, event_date))
        db.commit()
        flash("Event added successfully.")
        return redirect(url_for('view_events'))
    
    current_date = datetime.now().strftime('%Y-%m-%d')
    return render_template('add_event.html')



@app.route('/admin/edit_event/<int:event_id>', methods=['GET', 'POST'])
def edit_event(event_id):
    if 'user_id' not in session or session.get('username') != 'admin':
        flash("Admin access only.")
        return redirect(url_for('login'))

    db = get_db()
    event = db.execute("SELECT * FROM events WHERE id = ?", (event_id,)).fetchone()

    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        start_date = request.form['start_date']
        end_date = request.form['end_date']
        location = request.form['location']
        category = request.form['category']
        time = request.form['time']
        capacity = request.form['capacity']
        price = request.form['price']
        event_date = request.form['event_date']

        try:
            capacity = int(capacity)
            price = float(price)
            start_date_obj = datetime.strptime(start_date, '%Y-%m-%d')
            end_date_obj = datetime.strptime(end_date, '%Y-%m-%d')
            event_date_obj = datetime.strptime(event_date, '%Y-%m-%d')
        except ValueError:
            flash("Invalid input. Please check all numeric and date fields.")
            return redirect(url_for('edit_event', event_id=event_id))

        # Validate date logic
        if start_date_obj < datetime.now():
            flash("Start date cannot be in the past.")
            return redirect(url_for('edit_event', event_id=event_id))

        if end_date_obj <= start_date_obj:
            flash("End date must be after start date.")
            return redirect(url_for('edit_event', event_id=event_id))

        if not (event_date_obj > start_date_obj and event_date_obj > end_date_obj):
            flash("Event date must be after both start and end dates.")
            return redirect(url_for('edit_event', event_id=event_id))

        # Update the event in database
        db.execute("""
            UPDATE events
            SET title = ?, description = ?, start_date = ?, end_date = ?, location = ?, category = ?, time = ?, capacity = ?, price = ?, event_date = ?
            WHERE id = ?
        """, (title, description, start_date, end_date, location, category, time, capacity, price, event_date, event_id))
        db.commit()

        flash("Event updated successfully.")
        return redirect(url_for('view_events'))

    return render_template('edit_event.html', event=event)


@app.route('/admin/delete_event/<int:event_id>')
def delete_event(event_id):
    if 'user_id' not in session or session.get('username') != 'admin':
        flash("Admin access only.")
        return redirect(url_for('login'))

    db = get_db()
    deletion_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    db.execute("UPDATE events SET is_deleted = 1, deleted_at = ? WHERE id = ?", (deletion_time, event_id))
    db.commit()
    flash("Event moved to trash. It can be restored within 30 days.")
    return redirect(url_for('view_events'))

# @app.route('/admin/trashed_events')
# def trashed_events():
#     if 'user_id' not in session or session.get('username') != 'admin':
#         flash("Admin access only.")
#         return redirect(url_for('login'))

#     db = get_db()
#     one_minute_ago = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d %H:%M:%S')

#     events = db.execute("""
#         SELECT * FROM events
#         WHERE is_deleted = 1
#           AND deleted_at > ?
#           AND (archived IS NULL OR archived = 0)
#     """, (one_minute_ago,)).fetchall()    
#     return render_template('trashed_events.html', events=events)


@app.route('/admin/trashed_events')
def trashed_events():
    if 'user_id' not in session or session.get('username') != 'admin':
        flash("Admin access only.")
        return redirect(url_for('login'))

    db = get_db()

    # Full datetime comparison
    one_month_ago = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d %H:%M:%S')

    events = db.execute("""
        SELECT * FROM events
        WHERE is_deleted = 1
          AND deleted_at > ?
          AND (archived IS NULL OR archived = 0)
    """, (one_month_ago,)).fetchall()

    return render_template('trashed_events.html', events=events)


@app.route('/admin/restore_event/<int:event_id>')
def restore_event(event_id):
    if 'user_id' not in session or session.get('username') != 'admin':
        flash("Admin access only.")
        return redirect(url_for('login'))

    db = get_db()
    event = db.execute("SELECT * FROM events WHERE id = ? AND is_deleted = 1", (event_id,)).fetchone()
    
    if event:
        deleted_at = datetime.strptime(event['deleted_at'], '%Y-%m-%d %H:%M:%S')
        if datetime.now() - deleted_at <= timedelta(days=30):
            db.execute("UPDATE events SET is_deleted = 0, deleted_at = NULL WHERE id = ?", (event_id,))
            db.commit()
            flash("Event restored successfully.")
        else:
            flash("Cannot restore. 30-day recovery period has expired.")
    else:
        flash("Event not found or not in deleted state.")
    
    return redirect(url_for('view_events'))

class Config:
    SCHEDULER_API_ENABLED = True

app.config.from_object(Config())
scheduler = APScheduler()
scheduler.init_app(app)
scheduler.start()

def cleanup_old_deleted_events():
    with app.app_context():  # <-- required!
        db = get_db()
        cutoff_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d %H:%M:%S')
        print("Cleanup running at:", datetime.now(), "| Cutoff:", cutoff_date)

        rows = db.execute("SELECT * FROM events WHERE is_deleted = 1 AND deleted_at <= ?", (cutoff_date,)).fetchall()
        print("Events found to delete:", len(rows))

        # db.execute("DELETE FROM events WHERE is_deleted = 1 AND deleted_at <= ?", (cutoff_date,))
        # db.commit()


@app.route('/admin/run_cleanup')
def run_cleanup():
    cleanup_old_deleted_events()
    return "Cleanup run"

# Schedule it to run every 60 seconds
@scheduler.task('interval', id='cleanup_task', seconds=60)
def scheduled_cleanup():
    cleanup_old_deleted_events()

@app.route('/admin/archive_event/<int:event_id>')
def archive_event(event_id):
    if 'user_id' not in session or session.get('username') != 'admin':
        flash("Admin access only.")
        return redirect(url_for('login'))

    db = get_db()
    db.execute("UPDATE events SET archived = 1 WHERE id = ?", (event_id,))
    db.commit()
    print(f"Archived event with id: {event_id}")
    flash("Event hidden from Trash page.")
    return redirect(url_for('trashed_events'))

# Admin dashboard - show only non-deleted events
@app.route('/admin/events')
def admin_events():
    conn = sqlite3.connect('events.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM events WHERE deleted = 0')
    events = cursor.fetchall()
    conn.close()
    return render_template('admin_events.html', events=events)

@app.route('/admin/dashboard')
def admin_dashboard():
    if 'user_id' not in session or session.get('username') != 'admin':
        flash("Admin access only.")
        return redirect(url_for('login'))

    # Add logic for the admin dashboard here
    return render_template('admin_dashboard.html')

@app.route('/admin/view_events')
def view_events():
    if 'user_id' not in session or session.get('username') != 'admin':
        flash("Admin access only.")
        return redirect(url_for('login'))
    
    db = get_db()
    events = db.execute("SELECT * FROM events WHERE is_deleted = 0").fetchall() 
    msg = request.args.get('msg') # Ensure this query is correct
    print(events)
    return render_template('view_events.html', events=events)

@app.route('/event/<int:event_id>')
def event_detail(event_id):
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    # Get event details
    cursor.execute("SELECT * FROM events WHERE id=?", (event_id,))
    event = cursor.fetchone()

    # Calculate booked tickets
    cursor.execute("SELECT SUM(ticket_quantity) FROM bookings WHERE event_id=?", (event_id,))
    booked = cursor.fetchone()[0] or 0

    available_tickets = event['capacity'] - booked

    # Convert time to 12-hour format
    if event and event['time']:
        try:
            time_24 = datetime.strptime(event['time'], "%H:%M")
            time_12 = time_24.strftime("%I:%M %p")
        except:
            time_12 = event['time']
    else:
        time_12 = "N/A"

    from_page = request.args.get('from_page')

    conn.close()
    return render_template("event_detail.html", event=event, time_12=time_12, available_tickets=available_tickets, from_page=from_page)

def auto_mark_expired_events():
    db = get_db()
    today = datetime.today().date().isoformat()

    # Mark events as deleted if their end_date has passed and they are not already deleted
    db.execute("""
        UPDATE events
        SET is_deleted = 1,
            deleted_at = ?
        WHERE end_date < ? AND is_deleted = 0
    """, (today, today))
    db.commit()

@app.route('/tech')
def tech_page():
    auto_mark_expired_events()
    db = get_db()
    tech_events = db.execute(
        "SELECT * FROM events WHERE category = ? AND is_deleted = 0",
        ('Tech',)
    ).fetchall()
    return render_template('tech.html', tech_events=tech_events)

@app.route('/art')
def art_page():
    auto_mark_expired_events()
    db = get_db()
    art_events = db.execute(
        "SELECT * FROM events WHERE category = ? AND is_deleted = 0",
        ('Art',)
    ).fetchall()
    return render_template('art.html', art_events=art_events)

@app.route('/culture')
def culture_page():
    auto_mark_expired_events()
    db = get_db()
    culture_events = db.execute(
        "SELECT * FROM events WHERE category = ? AND is_deleted = 0",
        ('Culture',)
    ).fetchall()
    return render_template('culture.html', culture_events=culture_events)

@app.route('/fitness')
def fitness_page():
    auto_mark_expired_events()
    db = get_db()
    fitness_events = db.execute(
        "SELECT * FROM events WHERE category = ? AND is_deleted = 0",
        ('Fitness',)
    ).fetchall()
    return render_template('fitness.html', fitness_events=fitness_events)


# Step 1: Confirm Personal Info & Event Details
@app.route('/start_booking/<int:event_id>', methods=['GET', 'POST'])
def start_booking(event_id):
    session.pop('booking', None)  # 🔄 Clear previous
    session.modified = True
    if 'user_id' not in session:
        flash("Please login first.")
        return redirect(url_for('login'))

    db = get_db()
    user = db.execute("SELECT * FROM users WHERE id = ?", (session['user_id'],)).fetchone()
    event = db.execute("SELECT * FROM events WHERE id = ?", (event_id,)).fetchone()

    if request.method == 'POST':
        session['booking'] = {
            'event_id': event_id,
            'user_id': session['user_id']
        }
        return redirect(url_for('ticket_quantity'))

    return render_template('booking_step1_info.html', user=user, event=event,step=1)


@app.route('/ticket_quantity', methods=['GET', 'POST'])
def ticket_quantity():
    # Step 1: Ensure user is in the booking flow
    if 'booking' not in session:
        flash('Please start the booking process.')
        return redirect(url_for('index'))

    # Step 2: Get event info from DB
    db = get_db()
    event = db.execute("SELECT * FROM events WHERE id = ?", (session['booking']['event_id'],)).fetchone()

    if not event:
        flash("Event not found.")
        return redirect(url_for('index'))

    # Step 3: Handle POST (form submission)
    if request.method == 'POST':
       
        if request.form.get('action') == 'back':
            return redirect(url_for('start_booking', event_id=session['booking']['event_id']))



        try:
            quantity = int(request.form.get('quantity'))
        except (TypeError, ValueError):
            flash("Invalid ticket quantity.")
            return redirect(url_for('ticket_quantity'))

        # Handle possible None in available_tickets
        available_tickets = event['available_tickets']
        if available_tickets is None:
            flash("Ticket availability not configured for this event.")
            return redirect(url_for('index'))

        if quantity > available_tickets:
            flash(f"Only {available_tickets} tickets available.")
            return redirect(url_for('ticket_quantity'))

        # Save booking details in session
        session['booking']['ticket_quantity'] = quantity
        session['booking']['total_price'] = quantity * event['price']
        session.modified = True   # ✅ Force Flask to save session changes


        return redirect(url_for('payment_method'))

    # Step 4: Render the template for ticket selection
    return render_template('booking_step2_quantity.html', event=event, step=2)


# PayPal Sandbox Config
PAYPAL_CLIENT_ID = "AT6CYPhbIpT47LHrL1m1DyyS5IWgb8TLZYFAFVpVi0E1_KZF2QQrwUrWJz-TNplZKhbdoTccyDvu21xw"
PAYPAL_SECRET = "EHh4XuvE8U9TAsCdlUsd5uL88b3fMVjAcnDpt3tB2PMPg4TqmcAvza_-Rl0JGr26CeWDGOU5XdMGkQl_"
PAYPAL_API_BASE = "https://api-m.sandbox.paypal.com"


def get_paypal_access_token():
    auth = (PAYPAL_CLIENT_ID, PAYPAL_SECRET)
    headers = {"Accept": "application/json", "Accept-Language": "en_US"}
    data = {"grant_type": "client_credentials"}
    response = requests.post(f"{PAYPAL_API_BASE}/v1/oauth2/token", headers=headers, data=data, auth=auth)
    return response.json()['access_token']


@app.route('/payment_method', methods=['GET', 'POST'])
def payment_method():
    if 'booking' not in session:
        flash("Please start the booking process.")
        return redirect(url_for('index'))

    db = get_db()
    event = db.execute("SELECT * FROM events WHERE id = ?", (session['booking']['event_id'],)).fetchone()
    total_price_inr = session['booking'].get('total_price', event['price'])
    session['booking']['total_price'] = total_price_inr  # Store for later use
    session.modified = True

    # Convert INR to USD (for sandbox use only)
    inr_to_usd_rate = 0.012  # Approx conversion rate for testing
    total_price_usd = round(total_price_inr * inr_to_usd_rate, 2)

    if request.method == 'POST':

                # ✅ Handle back button
        if request.form.get('action') == 'back':
            return redirect(url_for('ticket_quantity'))


        access_token = get_paypal_access_token()
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {access_token}"
        }

        payment_payload = {
            "intent": "CAPTURE",
            "purchase_units": [{
                "amount": {
                    "currency_code": "USD",  # PayPal Sandbox prefers USD
                    "value": f"{total_price_usd:.2f}"
                }
            }],
            "application_context": {
                "return_url": url_for('payment_success', _external=True),
                "cancel_url": url_for('payment_cancel', _external=True)
            }
        }

        response = requests.post(f"{PAYPAL_API_BASE}/v2/checkout/orders", headers=headers, json=payment_payload)
        order = response.json()

        if response.status_code == 201 and 'links' in order:
            for link in order['links']:
                if link['rel'] == 'approve':
                    session['booking']['paypal_order_id'] = order['id']
                    session.modified = True
                    return redirect(link['href'])

        flash("Failed to create PayPal order.")
        return redirect(url_for('payment_method'))

    return render_template('booking_step3_payment.html', step=3, total_price=total_price_inr)


@app.route('/payment_success')
def payment_success():
    booking = session.get('booking')
    if not booking or 'paypal_order_id' not in booking:
        flash("Payment verification failed.")
        return redirect(url_for('index'))

    access_token = get_paypal_access_token()
    headers = {"Content-Type": "application/json", "Authorization": f"Bearer {access_token}"}
    order_id = booking['paypal_order_id']

    capture_url = f"{PAYPAL_API_BASE}/v2/checkout/orders/{order_id}/capture"
    response = requests.post(capture_url, headers=headers)
    capture_result = response.json()

    if 'status' in capture_result and capture_result['status'] == 'COMPLETED':
        session['booking']['payment_method'] = "PayPal"
        session.modified = True
        return redirect(url_for('confirm_booking'))
    else:
        flash("Payment was not successful. Please try again.")
        return redirect(url_for('payment_method'))


@app.route('/payment_cancel')
def payment_cancel():
    flash("Payment was cancelled.")
    return redirect(url_for('payment_method'))


# @app.route('/confirm_booking')
# def confirm_booking():
#     booking_data = session.get('booking')
#     if not booking_data:
#         flash("Booking session expired or not started.")
#         return redirect(url_for('index'))

#     required_keys = ['user_id', 'event_id', 'ticket_quantity', 'payment_method']
#     if not all(k in booking_data for k in required_keys):
#         flash("Incomplete booking data. Please restart the booking process.")
#         return redirect(url_for('start_booking', event_id=booking_data.get('event_id', 1)))

#     db = get_db()
#     db.execute(
#         "INSERT INTO bookings (user_id, event_id, ticket_quantity, payment_method, booking_date) VALUES (?, ?, ?, ?, ?)",
#         (
#             booking_data['user_id'],
#             booking_data['event_id'],
#             booking_data['ticket_quantity'],
#             booking_data['payment_method'],
#             datetime.now().strftime('%Y-%m-%d %H:%M:%S')
#         )
#     )
#     db.execute(
#         "UPDATE events SET available_tickets = available_tickets - ? WHERE id = ?",
#         (booking_data['ticket_quantity'], booking_data['event_id'])
#     )
#     db.commit()

#     session.pop('booking', None)
#     flash("Booking successful! Confirmation email sent.")
#     return redirect(url_for('profile', step=4))
@app.route('/confirm_booking')
def confirm_booking():
    booking_data = session.get('booking')
    if not booking_data:
        flash("Booking session expired or not started.")
        return redirect(url_for('index'))

    required_keys = ['user_id', 'event_id', 'ticket_quantity', 'payment_method']
    if not all(k in booking_data for k in required_keys):
        flash("Incomplete booking data. Please restart the booking process.")
        return redirect(url_for('start_booking', event_id=booking_data.get('event_id', 1)))

    db = get_db()

    # Fetch event and user details for email
    event = db.execute("SELECT * FROM events WHERE id = ?", (booking_data['event_id'],)).fetchone()
    user = db.execute("SELECT * FROM users WHERE id = ?", (booking_data['user_id'],)).fetchone()

    # Insert the booking
    db.execute(
        "INSERT INTO bookings (user_id, event_id, ticket_quantity, original_ticket_quantity, payment_method, booking_date) VALUES (?, ?, ?, ?, ?, ?)",
        (
            booking_data['user_id'],
            booking_data['event_id'],
            booking_data['ticket_quantity'],
            booking_data['ticket_quantity'],
            booking_data['payment_method'],
            datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        )
    )

    db.execute(
        "UPDATE events SET available_tickets = available_tickets - ? WHERE id = ?",
        (booking_data['ticket_quantity'], booking_data['event_id'])
    )
    db.commit()

    # ✅ Send email confirmation
    subject = f"Booking Confirmed: {event['title']}"
    body = f"""Hi {user['username']},

Thank you for booking with us!

Here are your booking details:

Event: {event['title']}
Date: {event['event_date']}
Location: {event['location']}
Tickets: {booking_data['ticket_quantity']}
Paid via: {booking_data['payment_method']}
Booked on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

We look forward to seeing you there!

Best regards,  
Event Management Team
"""
    send_email(user['email'], subject, body)

    # Clear session
    session.pop('booking', None)

    flash("Booking successful! Confirmation email sent.")
    return redirect(url_for('profile', step=4))


# wedding planning
@app.route('/wedding-themes')
def wedding_themes():
    db = get_db()
    themes = db.execute("SELECT * FROM wedding_themes").fetchall()
    return render_template('wedding_themes.html', themes=themes)

@app.route('/theme/<int:theme_id>')
def view_theme(theme_id):
    db = get_db()
    theme = db.execute("SELECT * FROM wedding_themes WHERE id = ?", (theme_id,)).fetchone()
    events = db.execute("SELECT * FROM theme_events WHERE theme_id = ?", (theme_id,)).fetchall()
    return render_template("theme_detail.html", theme=theme, events=events)

@app.route('/book-theme/<int:theme_id>', methods=['GET', 'POST'])
def book_theme(theme_id):
    if 'user_id' not in session:
        flash("Please log in to book a wedding theme.")
        return redirect(url_for('login'))

    db = get_db()
    theme = db.execute("SELECT * FROM wedding_themes WHERE id = ?", (theme_id,)).fetchone()

    events = [
        {'id': 1, 'event_name': 'Mehendi'},
        {'id': 2, 'event_name': 'Sangeet'},
        {'id': 3, 'event_name': 'Haldi'},
        {'id': 4, 'event_name': 'Reception'}
    ]

    if request.method == 'POST':
        user_id = session['user_id']
        guest_count = request.form['guest_count']
        booking_date = request.form['booking_date']
        user_name = request.form.get('user_name')
        user_email = request.form['user_email']
        user_contact = request.form['user_contact']
        venue = request.form['venue']
        bride_name = request.form.get('bride_name')
        groom_name = request.form.get('groom_name')
        booked_on = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        # Catering preferences
        catering_preferences = {}
        for event in events:
            menu = request.form.get(f'catering_menu_{event["id"]}')
            custom_menu = request.form.get(f'custom_menu_{event["id"]}')
            catering_preferences[event['event_name']] = custom_menu if custom_menu else menu

        catering_json = json.dumps(catering_preferences)

        db.execute(
            """INSERT INTO wedding_bookings 
            (user_id, theme_id, booking_date, guest_count, venue, full_name, email, phone, catering_preferences, booked_on, bride_name, groom_name) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (user_id, theme_id, booking_date, guest_count, venue, user_name, user_email, user_contact, catering_json, booked_on, bride_name, groom_name)
        )

        db.commit()

        flash("Your wedding theme has been booked. Please wait for admin confirmation via email.")
        return redirect(url_for('profile'))

    return render_template('book_theme.html', theme=theme, events=events)

  
@app.route('/add-guest-list/<int:theme_id>', methods=['GET', 'POST'])
def add_guest_list(theme_id):
    if 'user_id' not in session:
        flash("Please log in to add guests.")
        return redirect(url_for('login'))

    db = get_db()

    # Fetch theme info
    theme = db.execute("SELECT * FROM wedding_themes WHERE id = ?", (theme_id,)).fetchone()

    booking = db.execute(
        "SELECT * FROM wedding_bookings WHERE theme_id = ? AND user_id = ?",
        (theme_id, session['user_id'])
    ).fetchone()

    if not booking:
        flash("You haven't booked this theme yet.")
        return redirect(url_for('wedding_themes'))

    if request.method == 'POST':
        guest_name = request.form['guest_name']
        guest_email = request.form['guest_email']

        booking_id = booking['id']  # get booking id from booking object
        token = str(uuid.uuid4())  

        db.execute("""
            INSERT INTO wedding_guests 
            (guest_name, guest_email, booking_id,  token) 
            VALUES (?, ?, ?, ?)
        """, (guest_name, guest_email, booking_id,  token))

        db.commit()

        flash("Guest added successfully!")
        return redirect(url_for('add_guest_list', theme_id=theme_id))

    guests = db.execute(
        "SELECT * FROM wedding_guests WHERE booking_id = ?",
        (booking['id'],)
    ).fetchall()

    return render_template('add_guest_list.html', theme=theme, guests=guests)



@app.route('/admin-wedding-bookings', methods=['GET'])
def admin_wedding_bookings():
    if 'user_id' not in session or session.get('username') != 'admin':
        flash("You must be an admin to access this page.")
        return redirect(url_for('login'))
    
    db = get_db()
    bookings = db.execute("""
        SELECT wb.id, u.username, u.email, wt.name AS theme, wb.booking_date, wb.guest_count, wb.status, wb.booked_on
        FROM wedding_bookings wb
        JOIN users u ON wb.user_id = u.id
        JOIN wedding_themes wt ON wb.theme_id = wt.id
    """).fetchall()
    
    return render_template('admin_wedding_bookings.html', bookings=bookings)

@app.route('/admin-view-guests/<int:booking_id>', methods=['GET'])
def admin_view_guests(booking_id):
    if 'user_id' not in session or session.get('username') != 'admin':
        flash("You must be an admin to access this page.")
        return redirect(url_for('login'))

    db = get_db()
    guests = db.execute("""
        SELECT g.id, g.guest_name, g.guest_email, g.rsvp_status
        FROM wedding_guests g
        WHERE g.booking_id = ?
    """, (booking_id,)).fetchall()

    # Fetch booking details
    booking = db.execute("""
        SELECT id, user_id, venue, booking_date
        FROM wedding_bookings
        WHERE id = ?
    """, (booking_id,)).fetchone()

    if not booking:
        flash("Booking not found.", "error")
        return redirect(url_for('admin_view_bookings'))

    return render_template(
        'admin_view_guests.html',
        guests=guests,
        booking_id=booking["id"],
        user_id=booking["user_id"],  # <-- This is the correct user_id from the booking
        booking=booking
    )


@app.route('/admin-update-booking-status/<int:booking_id>', methods=['POST'])
def admin_update_booking_status(booking_id):
    if 'user_id' not in session or session.get('username') != 'admin':
        flash("Unauthorized access.")
        return redirect(url_for('login'))

    # Step 1: Get the new status from form (normalize to lowercase)
    new_status = request.form['status'].strip().lower()
    db = get_db()

    try:
        # Step 2: Update the booking status in the database
        db.execute("UPDATE wedding_bookings SET status = ? WHERE id = ?", (new_status, booking_id))
        db.commit()

        # Step 3: Fetch the updated booking and user info
        booking = db.execute("SELECT * FROM wedding_bookings WHERE id = ?", (booking_id,)).fetchone()
        print("Booking fetched:", dict(booking) if booking else "None")

        if booking:
            user = db.execute("SELECT username, email FROM users WHERE id = ?", (booking['user_id'],)).fetchone()
            print("👤 User fetched:", dict(user) if user else "None")

            if user and user['email']:
                # Step 4: Prepare email subject and body
                subject = "Wedding Booking Status Update"

                if new_status == "confirmed":
                    email_body = f"""
Hello {user['username']},

 We’re delighted to inform you that your wedding booking has been successfully confirmed. Thank you for choosing our Wedding Management System to be part of your special journey.

You can now take the next steps to bring your celebration to life:

Visit your profile to view your complete wedding plan
Create your personalized wedding invitation
Share it effortlessly with your guests

We’re here to ensure your big day is unforgettable — every detail, every moment.

If you have any questions or need assistance, our team is just a message away.

Warm wishes,
The Wedding Management Team
Crafting Memories, One Celebration at a Time
"""
                elif new_status == "cancelled":
                    email_body = f"""
Hello {user['username']},

We regret to inform you that your wedding booking has been cancelled.

We understand how important this occasion is, and we sincerely apologize for any inconvenience caused. If this cancellation was unexpected or if you believe it was made in error, please don’t hesitate to reach out to our support team — we’re here to help.

You can contact us at:
support@weddingmanagement.com
+91-XXXXXXXXXX

We hope to have the opportunity to assist you again in the future and make your special day everything you envision.

Warm regards,
The Wedding Management Team
Because every celebration deserves care.
"""
                else:
                    email_body = f"""
Hello {user['username']},

Your wedding booking status has been updated to: {new_status}.

Please check your profile for details.

Regards,  
- Wedding Management Team
"""

                print(" Sending email to:", user['email'])
                print(" Subject:", subject)
                print("Body:\n", email_body)

                # Step 5: Send the email
                send_email(user['email'], subject, email_body)
                flash("Status updated and email sent to user.")
            else:
                flash("Status updated, but email not sent (user not found or missing email).")
        else:
            flash("Booking not found.")
    except Exception as e:
        print("❌ Exception occurred:", e)
        flash("Status updated but failed to send email due to an error.")

    return redirect(url_for('admin_wedding_bookings'))




@app.route('/delete-wedding-booking/<int:booking_id>', methods=['POST'])
def delete_wedding_booking(booking_id):
    if 'user_id' not in session or session.get('username') != 'admin':
        flash("Unauthorized access.")
        return redirect(url_for('login'))

    db = get_db()
    db.execute("DELETE FROM wedding_bookings WHERE id = ?", (booking_id,))
    db.commit()

    flash("Booking deleted.")


@app.route('/rsvp-guest/<int:guest_id>', methods=['POST'])
def rsvp_guest(guest_id):
    if 'user_id' not in session:
        flash("Please log in to update RSVP.")
        return redirect(url_for('login'))

    db = get_db()
    guest = db.execute("SELECT * FROM wedding_guests WHERE id = ?", (guest_id,)).fetchone()

    if not guest:
        flash("Guest not found.")
        return redirect(url_for('add_guest_list', theme_id=guest['theme_id']))

    new_rsvp = request.form['rsvp_status']
    db.execute("UPDATE wedding_guests SET rsvp_status = ? WHERE id = ?", (new_rsvp, guest_id))
    db.commit()

    flash("RSVP updated successfully!")
    return redirect(url_for('add_guest_list', theme_id=guest['theme_id']))


@app.route('/rsvp/<token>', methods=['GET', 'POST'])
def rsvp_guest_token(token):
    db = get_db()
    guest = db.execute("SELECT * FROM wedding_guests WHERE token = ?", (token,)).fetchone()
    if not guest:
        return "Invalid RSVP link."

    if request.method == 'POST':
        status = request.form.get('rsvp')
        db.execute("UPDATE wedding_guests SET rsvp_status = ? WHERE token = ?", (status, token))
        db.commit()
        return f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>RSVP Confirmed</title>
        </head>
        <body style="font-family: Arial; text-align: center; padding: 50px;">
            <h2>Thank you, {guest['guest_name']}!</h2>
            <p>Your RSVP "<strong>{status}</strong>" has been recorded successfully.</p>
        </body>
        </html>
        """

    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Wedding RSVP</title>
        <style>
            body {{
                font-family: Arial, sans-serif;
                padding: 30px;
                background-color: #f4f4f4;
                text-align: center;
            }}
            .container {{
                background-color: white;
                padding: 40px;
                border-radius: 12px;
                max-width: 500px;
                margin: auto;
                box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            }}
            h2 {{
                color: #333;
            }}
            button {{
                padding: 12px 25px;
                font-size: 16px;
                margin: 10px;
                border: none;
                border-radius: 8px;
                cursor: pointer;
            }}
            .yes {{
                background-color: #28a745;
                color: white;
            }}
            .no {{
                background-color: #dc3545;
                color: white;
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <h2>Hi {guest['guest_name']}!</h2>
            <p>Will you attend the wedding?</p>
            <form method="POST">
                <button type="submit" name="rsvp" value="Yes" class="yes">Yes, I’ll attend</button>
                <button type="submit" name="rsvp" value="No" class="no">No, I can’t make it</button>
            </form>
        </div>
    </body>
    </html>
    """

@app.route('/admin/rsvp_status/<int:booking_id>')
def admin_rsvp_status(booking_id):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    cursor.execute("SELECT guest_name, guest_email, rsvp_status FROM wedding_guests WHERE booking_id = ?", (booking_id,))
    guests = cursor.fetchall()

    cursor.execute("SELECT COUNT(*) FROM wedding_guests WHERE booking_id = ?", (booking_id,))
    total = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM wedding_guests WHERE booking_id = ? AND rsvp_status = 'Yes'", (booking_id,))
    yes_count = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM wedding_guests WHERE booking_id = ? AND rsvp_status = 'No'", (booking_id,))
    no_count = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM wedding_guests WHERE booking_id = ? AND rsvp_status = 'Maybe'", (booking_id,))
    maybe_count = cursor.fetchone()[0]

    conn.close()

    return render_template(
    'admin_rsvp_status.html',
    guests=guests,
    total=total,
    yes_count=yes_count,
    no_count=no_count,
    maybe_count=maybe_count,
    booking_id=booking_id  # ✅ This is what was missing!
)


@app.route('/admin/download_rsvp_csv/<int:booking_id>')
def download_rsvp_csv(booking_id):
    conn = sqlite3.connect('database.db')  # Fix your DB name if incorrect
    cursor = conn.cursor()
    cursor.execute("SELECT guest_name, guest_email, rsvp_status FROM wedding_guests WHERE booking_id = ?", (booking_id,))
    guests = cursor.fetchall()
    conn.close()

    # ✅ Create an in-memory CSV file
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Guest Name", "Guest Email", "RSVP Status"])
    for guest in guests:
        writer.writerow(guest)

    # ✅ Create Flask response from output
    response = make_response(output.getvalue())
    response.headers["Content-Disposition"] = "attachment; filename=rsvp_status.csv"
    response.headers["Content-type"] = "text/csv"

    return response




@app.route('/admin/booking/<int:booking_id>/send-invitations', methods=['POST'])
def send_invitation_emails(booking_id):
    booking = get_wedding_booking_by_id(booking_id)
    if not booking:
        flash("Booking not found.", "error")
        return redirect(url_for('admin_view_bookings'))

    guests = get_guests_for_booking(booking_id)
    if not guests:
        flash("No guests found for this booking.", "warning")
        return redirect(url_for('admin_view_guests', booking_id=booking_id))

    for guest in guests:
        # Make sure keys match your DB fields
        guest_name = guest.get('guest_name')
        guest_email = guest.get('guest_email')
        guest_token = guest.get('token')

        if not guest_name or not guest_email or not guest_token:
            flash(f"Missing data for guest {guest_name or 'Unknown'}", "error")
            continue

        rsvp_link = url_for('rsvp_guest_token', token=guest['token'], _external=True)


        body = f"""
        Dear {guest_name},

        You're invited to a beautiful wedding!

         Theme: {booking['theme']}
         Venue: {booking['venue']}
         Date: {booking['booking_date']}

        Please RSVP here: <a href="{rsvp_link}">rsvp_link</a>

        Regards,
        Wedding Management Team
        """

        send_email(
            recipient=guest_email,
            subject="You're Invited to a Wedding!",
            body=body
        )

    flash("Invitations sent to all guests successfully!", "success")
    return redirect(url_for('admin_view_guests', booking_id=booking_id))



@app.route('/theme/<int:theme_id>')
def show_theme(theme_id):
    theme = WeddingTheme.query.get_or_404(theme_id)
    events = ThemeEvent.query.filter_by(theme_id=theme_id).all()

    total_price = sum(event.price for event in events)

    return render_template('theme.html', theme=theme, events=events, total_price=total_price)


@app.route('/send-test-email')
def send_test_email():
    try:
        send_email(
            recipient="diksaraswati5@gmail.com",  # <-- Replace with your actual email
            subject="Test Email from Wedding App",
            body="Hello! This is a test email to confirm your setup works."
        )
        return "✅ Test email sent successfully! Check your inbox."
    except Exception as e:
        return f"❌ Failed to send test email: {e}"
@app.route('/test-mail')
def test_mail():
    try:
        send_email("diksaraswati5@gmail.com", 'Test Subject', 'This is a test email')
        return "✅ Email sent successfully."
    except Exception as e:
        return f"❌ Email failed: {str(e)}"

 # Define this near your other helper functions
def get_booking(booking_id):
    db = get_db()
    return db.execute("SELECT * FROM wedding_bookings WHERE id = ?", (booking_id,)).fetchone()
   
def get_theme(theme_id):
    db = get_db()
    return db.execute("SELECT * FROM wedding_themes WHERE id = ?", (theme_id,)).fetchone()

def get_theme_events(theme_id):
    db = get_db()
    return db.execute("SELECT * FROM wedding_event WHERE theme_id = ?", (theme_id,)).fetchall()

def get_user(user_id):
    db = get_db()
    return db.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()

def update_booking_status(booking_id, new_status):
    db = get_db()
    db.execute("UPDATE wedding_bookings SET status = ? WHERE id = ?", (new_status, booking_id))
    db.commit()



def generate_pdf_from_template(booking, theme, events, user, all_vendors, total_price):
    # Path to wkhtmltopdf executable
    path_wkhtmltopdf = r'C:\Program Files\wkhtmltopdf\bin\wkhtmltopdf.exe'
    config = pdfkit.configuration(wkhtmltopdf=path_wkhtmltopdf)

     # Add this: define booking_obj safely
    booking_obj = {
        'catering_preferences': booking.catering_preferences if hasattr(booking, 'catering_preferences') else 'N/A'
    }

    # Render the HTML template
    rendered = render_template(
        'admin_wedding_booking_pdf.html',
        booking=booking,
        theme=theme,
        events=events,
        user=user,
        all_vendors=all_vendors,
        booking_obj=booking_obj,
        total_price=total_price
    )

    # Set the output PDF file path
    pdf_filename = f"wedding_plan_booking_{booking['id']}.pdf"
    pdf_path = os.path.join('static', 'pdfs', pdf_filename)
    os.makedirs(os.path.dirname(pdf_path), exist_ok=True)

    # Generate PDF from rendered HTML
    pdfkit.from_string(rendered, pdf_path, configuration=config)

    return pdf_path

from flask import make_response




def get_all_vendors_for_booking(booking_id):
    import sqlite3

    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    # Step 1: Get the theme_id from wedding_bookings
    cur.execute("SELECT theme_id FROM wedding_bookings WHERE id = ?", (booking_id,))
    row = cur.fetchone()
    if not row:
        conn.close()
        return {}

    theme_id = row["theme_id"]

    # Step 2: Get all events related to this theme
    cur.execute("SELECT id, event_name FROM theme_events WHERE theme_id = ?", (theme_id,))
    events = cur.fetchall()

    # Step 3: Get all vendors assigned to these events
    event_ids = [event["id"] for event in events]
    if not event_ids:
        conn.close()
        return {}

    placeholders = ','.join(['?'] * len(event_ids))
    query = f"""
        SELECT 
            tev.event_name,
            v.category,
            v.name AS vendor_name,
            v.email,
            v.phone
        FROM event_vendor ev
        JOIN theme_events tev ON ev.event_id = tev.id
        JOIN vendor v ON ev.vendor_id = v.id
        WHERE ev.event_id IN ({placeholders})
    """
    cur.execute(query, event_ids)
    vendor_rows = cur.fetchall()
    conn.close()

    # Step 4: Group by event_name and category
    grouped = {}
    for row in vendor_rows:
        event = row["event_name"]
        category = row["category"]

        if event not in grouped:
            grouped[event] = {}
        grouped[event][category] = {
            "vendor_name": row["vendor_name"],
            "email": row["email"],
            "phone": row["phone"]
        }

    return grouped


    # Group by event name and category
    grouped = {}
    for row in vendor_data:
        key = row["event_name"]
        if key not in grouped:
            grouped[key] = {}
        grouped[key][row["category"]] = {
            "vendor_name": row["vendor_name"],
            "email": row["email"],
            "phone": row["phone"]
        }
    return grouped

def send_email(recipient, subject, body, attachment_path=None):
    sender_email = "diksaraswati5@gmail.com"
    sender_password = "emej zljq gual vhme"

    try:
        msg = MIMEMultipart()
        msg['From'] = sender_email
        msg['To'] = recipient
        msg['Subject'] = subject

        msg.attach(MIMEText(body, 'plain', _charset='utf-8'))

        if attachment_path:
            with open(attachment_path, 'rb') as f:
                part = MIMEApplication(f.read(), Name=os.path.basename(attachment_path))
                part['Content-Disposition'] = f'attachment; filename="{os.path.basename(attachment_path)}"'
                msg.attach(part)

        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as server:
            server.login(sender_email, sender_password)
            server.sendmail(sender_email, recipient, msg.as_string())

        print(f"✅ Email sent to {recipient}")

    except Exception as e:
        print(f"❌ Failed to send email to {recipient}: {e}")



@app.route('/admin/generate_pdf_send_email/<int:booking_id>', methods=['POST'])
def admin_generate_pdf_send_email(booking_id):
    db = get_db()

    booking = dict(get_booking(booking_id))
    user = dict(get_user(booking['user_id']))
    theme = dict(get_theme(booking['theme_id']))
    theme_id = theme['id']
    booking_obj = dict(get_booking(booking_id))

    rows = db.execute("""
        SELECT te.id AS event_id, te.event_name, te.image_url,
               te.decoration, te.staff, te.catering, te.photography,
               te.makeup, te.makeup_price, te.dj, te.dj_price, te.price,
               v.name AS vendor_name, v.category AS vendor_type,
               v.email, v.phone, v.price AS vendor_price
        FROM theme_events te
        LEFT JOIN event_vendor ev ON ev.event_id = te.id
        LEFT JOIN vendor v ON v.id = ev.vendor_id
        WHERE te.theme_id = ?
    """, (theme_id,)).fetchall()

    events = {}
    total_price = 0

    for row in rows:
        eid = row['event_id']
        if eid not in events:
            events[eid] = {
                'event_name': row['event_name'],
                'image_url': row['image_url'],
                'decoration': row['decoration'],
                'staff': row['staff'] if 'staff' in row.keys() else None,
                'catering': row['catering'],
                'photography': row['photography'],
                'makeup': row['makeup'],
                'makeup_price': row['makeup_price'],
                'dj': row['dj'],
                'dj_price': row['dj_price'],
                'price': row['price'],
                'vendors': []
            }

            if row['price']:
                total_price += row['price']

        if row['vendor_name']:
            vendor_price = row['vendor_price'] if row['vendor_price'] else 0
            events[eid]['vendors'].append({
                'name': row['vendor_name'],
                'type': row['vendor_type'],
                'email': row['email'],
                'phone': row['phone'],
                'price': vendor_price
            })
            total_price += vendor_price

    event_list = list(events.values())

    all_vendors = []
    seen = set()
    for event in event_list:
        for vendor in event.get('vendors', []):
            key = (vendor['name'], vendor['type'])
            if key not in seen:
                seen.add(key)
                all_vendors.append(vendor)

    # ✅ Generate PDF using reportlab
    pdf_buffer = io.BytesIO()
    c = canvas.Canvas(pdf_buffer, pagesize=letter)
    width, height = letter
    y = height - 50

    c.setFont("Helvetica-Bold", 16)
    c.drawString(50, y, "Wedding Plan Summary")
    y -= 30

    c.setFont("Helvetica", 12)
    c.drawString(50, y, f"Bride: {booking['bride_name']} | Groom: {booking['groom_name']}")
    y -= 20
    c.drawString(50, y, f"Wedding Date: {booking['booking_date']} | Booked On: {booking['booked_on']}")
    y -= 20
    c.drawString(50, y, f"Venue: {booking['venue']} | Guests: {booking['guest_count']}")
    y -= 30

    c.setFont("Helvetica-Bold", 14)
    c.drawString(50, y, f"Theme: {theme['name']}")
    y -= 20
    c.setFont("Helvetica", 12)
    c.drawString(50, y, f"Description: {theme['description']}")
    y -= 30

    for event in event_list:
        c.setFont("Helvetica-Bold", 13)
        c.drawString(50, y, f"Event: {event['event_name']}")
        y -= 20
        c.setFont("Helvetica", 12)
        c.drawString(60, y, f"Decoration: {event['decoration']}")
        y -= 20
        c.drawString(60, y, f"Catering: {event['catering']} | Photography: {event['photography']}")
        y -= 20
        if event.get('makeup'):
            c.drawString(60, y, f"Makeup: {event['makeup']} ")
            y -= 20
        if event.get('dj'):
            c.drawString(60, y, f"DJ: {event['dj']} ")
            # (₹{event['dj_price']})
            y -= 20
        # c.drawString(60, y, f"Event Price: ₹{event['price']}")
        y -= 25

        for vendor in event['vendors']:
            c.drawString(70, y, f"Vendor: {vendor['type']} - {vendor['name']} ")
            # (₹{vendor['price']})
            y -= 20
            c.drawString(80, y, f"Contact: {vendor['email']}, {vendor['phone']}")
            y -= 25

        y -= 10
        if y < 100:
            c.showPage()
            y = height - 50

    c.setFont("Helvetica-Bold", 14)
    c.drawString(50, y, f"Total Price: ₹{total_price}")
    c.save()



    pdf_buffer.seek(0)

    pdf_data = pdf_buffer.read()
    pdf_path = os.path.join(tempfile.gettempdir(), "Wedding_Details.pdf")

    with open(pdf_path, 'wb') as f:
        f.write(pdf_data)

    # ✅ Send Email
    try:
        send_email(
            recipient=user['email'],
            subject="Your Wedding Plan is Confirmed!",
            body="Congratulations! Please find attached your complete wedding plan in PDF format.",
            attachment_path=pdf_path  # ✅ fixed line
        )
        flash("Wedding plan email sent successfully.")
    except Exception as e:
        flash(f"Email sending failed: {e}")
        return redirect(url_for('admin_wedding_bookings'))

    # ✅ Clean up
    os.remove(pdf_path)
    return redirect(url_for('admin_wedding_bookings'))







@app.route('/download-wedding-plan/<int:booking_id>')
def download_wedding_plan(booking_id):
    db = get_db()

    booking = db.execute("SELECT * FROM wedding_bookings WHERE id = ?", (booking_id,)).fetchone()
    if not booking:
        flash("Booking not found")
        return redirect(url_for('admin_dashboard'))

    events_raw = db.execute("""
        SELECT we.name AS event_name, v.type AS vendor_type, v.name AS vendor_name,
               v.email, v.phone, v.price, v.image_path
        FROM wedding_event we
        LEFT JOIN event_vendors ev ON ev.event_id = we.id
        LEFT JOIN vendors v ON v.id = ev.vendor_id
        WHERE we.booking_id = ?
    """, (booking_id,)).fetchall()

    events_dict = {}
    for row in events_raw:
        name = row['event_name']
        if name not in events_dict:
            events_dict[name] = {}
        if row['vendor_type']:
            events_dict[name][row['vendor_type']] = {
                'name': row['vendor_name'],
                'email': row['email'],
                'phone': row['phone'],
                'price': row['price'],
                'image_path': row['image_path']
            }

    booking_data = {
        'id': booking['id'],
        'bride_name': booking['bride_name'],
        'groom_name': booking['groom_name'],
        'guest_count': booking['guest_count'],
        'venue': booking['venue'],
        'booking_date': booking['booking_date'],
        'theme_name': booking['theme_name'],
        'total_price': booking['total_price'],
        'notes': booking['notes'],
        'events': []
    }

    for event_name, vendors in events_dict.items():
        booking_data['events'].append({
            'name': event_name,
            **vendors
        })

    # Generate PDF
    pdf_path = generate_wedding_plan_pdf(booking_data)
    return send_file(pdf_path, as_attachment=True)

@app.route('/admin/preview_pdf/<int:booking_id>')
def preview_pdf_page(booking_id):
    db = get_db()

    booking = dict(get_booking(booking_id))
    user = dict(get_user(booking['user_id']))
    theme = dict(get_theme(booking['theme_id']))
    theme_id = theme['id']
    booking_obj = dict(get_booking(booking_id))

    rows = db.execute("""
        SELECT te.id AS event_id, te.event_name, te.image_url,
               te.decoration, te.staff, te.catering, te.photography,
               te.makeup, te.makeup_price, te.dj, te.dj_price, te.price,
               v.name AS vendor_name, v.category AS vendor_type,
               v.email, v.phone, v.price AS vendor_price
        FROM theme_events te
        LEFT JOIN event_vendor ev ON ev.event_id = te.id
        LEFT JOIN vendor v ON v.id = ev.vendor_id
        WHERE te.theme_id = ?
    """, (theme_id,)).fetchall()

    events = {}
    total_price = 0  # Initialize total price

    for row in rows:
        eid = row['event_id']
        if eid not in events:
            events[eid] = {
                'event_name': row['event_name'],
                'image_url': row['image_url'],
                'decoration': row['decoration'],
                'staff': row['staff'] if 'staff' in row.keys() else None,
                'catering': row['catering'],
                'photography': row['photography'],
                'makeup': row['makeup'],
                'makeup_price': row['makeup_price'],
                'dj': row['dj'],
                'dj_price': row['dj_price'],
                'price': row['price'],
                'vendors': []
            }

            if row['price']:
                total_price += row['price']  # Add event price

        if row['vendor_name']:
            vendor_price = row['vendor_price'] if row['vendor_price'] else 0
            events[eid]['vendors'].append({
                'name': row['vendor_name'],
                'type': row['vendor_type'],
                'email': row['email'],
                'phone': row['phone'],
                'price': vendor_price
            })
            total_price += vendor_price  # Add vendor price

    event_list = list(events.values())

    all_vendors = []
    seen = set()
    for event in event_list:
        for vendor in event.get('vendors', []):
            key = (vendor['name'], vendor['type'])
            if key not in seen:
                seen.add(key)
                all_vendors.append(vendor)

    return render_template('admin_pdf_preview.html',
                           booking=booking,
                           user=user,
                           theme=theme,
                           events=event_list,
                           all_vendors=all_vendors,
                           booking_obj=booking_obj,
                           total_price=total_price)

@app.route('/create-invitation/<int:booking_id>')
def create_invitation(booking_id):
    db = get_db()
    booking = db.execute("SELECT * FROM wedding_bookings WHERE id = ?", (booking_id,)).fetchone()

    template_folder = os.path.join('static', 'invitation_templates')
    all_files = os.listdir(template_folder)
    templates = []

    # Filter only valid image files
    for file in all_files:
        file_path = os.path.join(template_folder, file)
        # Check if it's a valid image
        if imghdr.what(file_path):
            # Additional check: ensure Pillow can open it
            try:
                # with Image.open(file_path) as img:
                #     img.verify()  # Verify image integrity
                templates.append(file)
            except Exception as e:
                print(f"Skipped invalid/corrupt image: {file} ({e})")

    message = f"""
    You're invited to the wedding of {booking['bride_name']} & {booking['groom_name']}!
    Venue: {booking['venue']}
    Date: {booking['booking_date']}
    Click to view invitation: {request.host_url}invitation/{booking_id}
    """

    return render_template('create_invitation.html',
                           booking=booking,
                           templates=templates,
                           whatsapp_message=message,
                           email_message=message)



@app.route('/invitation_templates/<int:booking_id>')
def invitation_templates(booking_id):
    if 'user_id' not in session:
        flash("Please login first.")
        return redirect(url_for('login'))

    db = get_db()
    booking = db.execute(
        "SELECT * FROM wedding_bookings WHERE id = ? AND user_id = ?", 
        (booking_id, session['user_id'])
    ).fetchone()

    if not booking:
        flash("Invalid booking or unauthorized access.")
        return redirect(url_for('profile'))

    templates = ['template_1.jpg']
    return render_template('invitation_templates.html', booking=booking, booking_id=booking_id)








UPLOAD_FOLDER = 'static/uploads'
# 🧩 Edit form route
@app.route('/edit_invitation_form/<int:booking_id>', methods=['POST'])
def edit_invitation_form(booking_id):
    if 'user_id' not in session:
        flash("Please login first.")
        return redirect(url_for('login'))

    selected_template = request.form.get('selected_template')
    if not selected_template:
        flash("No template selected.")
        return redirect(url_for('invitation_templates', booking_id=booking_id))

    try:
        template_id = int(selected_template.split('_')[1].split('.')[0])
    except (IndexError, ValueError):
        flash("Invalid template format.")
        return redirect(url_for('invitation_templates', booking_id=booking_id))

    db = get_db()
    booking = db.execute(
        "SELECT * FROM wedding_bookings WHERE id = ? AND user_id = ?", 
        (booking_id, session['user_id'])
    ).fetchone()

    if not booking:
        flash("Unauthorized or invalid booking.")
        return redirect(url_for('profile'))

    invitation_data = {
        "title": "You're Invited!",
        "names": f"{booking['bride_name']} & {booking['groom_name']}",
        "date": booking['booking_date'],
        "location": booking['venue'],
        "message": "We would love your presence on our special day.",
        "template_id": template_id
    }

    return render_template(
        'edit_invitation_form.html',
        template_file=selected_template,
        booking=booking,
        invitation=invitation_data
    )

# 🧩 Preview route
@app.route('/preview_invitation/<int:booking_id>', methods=['POST'])
def preview_invitation(booking_id):
    db = get_db()
    booking = db.execute("SELECT * FROM wedding_bookings WHERE id = ?", (booking_id,)).fetchone()

    if not booking:
        flash("Invalid booking.")
        return redirect(url_for('profile'))

    # These values are submitted from edit form
    title = request.form.get("title")
    names = request.form.get("names")
    date = request.form.get("date")
    location = request.form.get("location")
    message = request.form.get("message")
    template_file = request.form.get("template_file")

    if not all([title, names, date, location, message, template_file]):
        flash("All invitation fields are required.")
        return redirect(url_for('edit_invitation_form', booking_id=booking_id))

    template = {
        "id": template_file,
        "name": f"Elegant Design: {template_file}",
        "description": "Beautiful floral wedding invite",
        "background_image": template_file
    }

    photo_url = None
    if 'photo' in request.files:
        photo = request.files['photo']
        if photo and photo.filename:
            filename = secure_filename(photo.filename)
            photo_path = os.path.join(UPLOAD_FOLDER, filename)
            photo.save(photo_path)
            photo_url = '/' + photo_path.replace("\\", "/")  # Ensure proper URL

    whatsapp_text = f"{title}\n{names}\nDate: {date}\nVenue: {location}\n{message}"

    return render_template(
        "preview_invitation.html",
        booking=booking,
        template=template,
        title=title,
        names=names,
        date=date,
        location=location,
        message=message,
        booking_id=booking_id,
        whatsapp_text=whatsapp_text,
          photo_url=photo_url
    )


@app.route('/download_invitation_pdf_custom/<int:booking_id>')
def download_invitation_pdf_custom(booking_id):
    title = request.args.get('title')
    names = request.args.get('names')
    date = request.args.get('date')
    location = request.args.get('location')
    message = request.args.get('message')
    photo_url = request.args.get('photo_url')  # Optional

    # Ensure full static path for image if used
    if not photo_url or 'default_couple.png' in photo_url:
        photo_url = url_for('static', filename='default_couple.png', _external=True)

    html = render_template(
        'pdf_invitation_template.html',
        title=title,
        names=names,
        date=date,
        location=location,
        message=message,
        photo_url=photo_url
    )

    result = BytesIO()
    pisa_status = pisa.CreatePDF(html, dest=result)

    if pisa_status.err:
        return "PDF generation error", 500

    result.seek(0)
    return send_file(result, download_name="invitation.pdf", as_attachment=True)

# @app.route('/download_invitation_pdf_custom/<int:booking_id>')
# def download_invitation_pdf_custom(booking_id):
#     title = request.args.get('title')
#     names = request.args.get('names')
#     date = request.args.get('date')
#     location = request.args.get('location')
#     message = request.args.get('message')

#     html = render_template_string("""
#     <html>
#     <head><style>
#         body { font-family: Georgia, serif; padding: 40px; }
#         h1 { color: #d63384; }
#         p { font-size: 16px; margin: 10px 0; }
#     </style></head>
#     <body>
#         <h1>{{ title }}</h1>
#         <p><strong>Names:</strong> {{ names }}</p>
#         <p><strong>Date:</strong> {{ date }}</p>
#         <p><strong>Location:</strong> {{ location }}</p>
#         <p>{{ message }}</p>
#     </body></html>
#     """, title=title, names=names, date=date, location=location, message=message)

#     result = BytesIO()
#     pisa_status = pisa.CreatePDF(html, dest=result)
#     if pisa_status.err:
#         return "PDF generation error", 500
#     result.seek(0)
#     return send_file(result, download_name="invitation.pdf", as_attachment=True)


import urllib.parse

@app.template_filter('url_encode')
def url_encode_filter(s):
    if s is None:
        return ''
    return urllib.parse.quote_plus(s)

@app.route('/events/<category>')
def category_events(category):
    db = get_db()
    events = db.execute('SELECT * FROM events WHERE category = ?', (category,)).fetchall()
    return render_template(f'{category}.html', events=events, category=category)






if __name__ == '__main__':
    app.run(debug=True)
    # app.run(host='0.0.0.0', port=5000)

