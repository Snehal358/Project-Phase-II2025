# import sqlite3

# # Update this with your actual database file
# DATABASE = 'database.db'  # or 'instance/wedding.db' if stored in instance folder

# # Connect to the database
# conn = sqlite3.connect(DATABASE)
# cursor = conn.cursor()

# # Get all table names
# cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
# tables = cursor.fetchall()

# # Loop through each table and print column info
# for table in tables:
#     table_name = table[0]
#     print(f"\n📦 Table: {table_name}")
#     cursor.execute(f"PRAGMA table_info({table_name});")
#     columns = cursor.fetchall()
#     for col in columns:
#         cid, name, col_type, notnull, default_value, pk = col
#         print(f"   - {name} ({col_type})")
# # 
# conn.close()


# import sqlite3

# # 1. Connect to your SQLite database
# conn = sqlite3.connect('database.db')  # Example: 'database.db'

# # 2. Create a cursor object
# cursor = conn.cursor()

# # 3. Execute a SELECT query
# cursor.execute("SELECT * FROM events")  # Example: 'theme_events'

# # 4. Fetch all results
# rows = cursor.fetchall()

# # 5. Print results
# for row in rows:
#     print(row)

# # 6. Close the connection
# conn.close()

# import sqlite3

# def clone_vendors_for_themes():
#     db = sqlite3.connect("database.db")
#     db.row_factory = sqlite3.Row
#     cursor = db.cursor()

#     # Get Royal theme events with vendors
#     royal_theme_id = 1
#     other_theme_ids = [2, 3, 4, 5]

#     # Fetch all (event_name, event_id) for Royal theme
#     royal_events = cursor.execute("""
#         SELECT id, event_name FROM theme_events WHERE theme_id = ?
#     """, (royal_theme_id,)).fetchall()
#     royal_event_map = {row['event_name']: row['id'] for row in royal_events}

#     # Fetch all vendor links for Royal theme events
#     vendor_links = cursor.execute("""
#         SELECT event_id, vendor_id FROM event_vendor
#         WHERE event_id IN (SELECT id FROM theme_events WHERE theme_id = ?)
#     """, (royal_theme_id,)).fetchall()

#     # Build a map of event_name to vendor_id list
#     event_vendor_map = {}
#     for link in vendor_links:
#         event_name = cursor.execute("SELECT event_name FROM theme_events WHERE id = ?", (link['event_id'],)).fetchone()['event_name']
#         event_vendor_map.setdefault(event_name, []).append(link['vendor_id'])

#     # Now apply these vendor_ids to same-named events in other themes
#     for theme_id in other_theme_ids:
#         events = cursor.execute("""
#             SELECT id, event_name FROM theme_events WHERE theme_id = ?
#         """, (theme_id,)).fetchall()

#         for event in events:
#             eid = event['id']
#             ename = event['event_name']
#             vendor_ids = event_vendor_map.get(ename, [])
#             for vid in vendor_ids:
#                 # Check if already exists to avoid duplicates
#                 exists = cursor.execute("""
#                     SELECT 1 FROM event_vendor WHERE event_id = ? AND vendor_id = ?
#                 """, (eid, vid)).fetchone()
#                 if not exists:
#                     cursor.execute("INSERT INTO event_vendor (event_id, vendor_id) VALUES (?, ?)", (eid, vid))
#                     print(f"Linked vendor {vid} to event '{ename}' (Theme {theme_id})")

#     db.commit()
#     db.close()
#     print("Vendor cloning complete.")

# clone_vendors_for_themes()

# import sqlite3

# # Connect to your SQLite database
# conn = sqlite3.connect('database.db')
# cursor = conn.cursor()

# # Add the new column
# cursor.execute("ALTER TABLE events ADD COLUMN event_date TEXT")

# # Commit and close
# conn.commit()
# conn.close()

# print("event_date column added successfully.")

# import sqlite3

# conn = sqlite3.connect('database.db')
# cursor = conn.cursor()

# # USERS table
# cursor.execute('''
# CREATE TABLE invitation_templates (
#     id INTEGER PRIMARY KEY AUTOINCREMENT,
#     name TEXT,
#     image_url TEXT,
#     html_template TEXT  -- store HTML content with placeholders
# )

# ''')

# cursor.execute('''
# CREATE TABLE user_invitations (
#     id INTEGER PRIMARY KEY AUTOINCREMENT,
#     booking_id INTEGER,
#     template_id INTEGER,
#     bride_name TEXT,
#     groom_name TEXT,
#     wedding_date TEXT,
#     venue TEXT,
#     photo_url TEXT,
#     message TEXT,
#     FOREIGN KEY (booking_id) REFERENCES bookings(id),
#     FOREIGN KEY (template_id) REFERENCES invitation_templates(id)
# )''')


# conn.commit()
# conn.close()

# print("complete ✅")


# import sqlite3

# conn = sqlite3.connect('database.db')
# cursor = conn.cursor()

# # Template 1 - Royal Blue & Gold
# cursor.execute("""
# INSERT INTO invitation_templates (name, image_url, html_template)
# VALUES (?, ?, ?)
# """, (
#     "Royal Blue & Gold",
#     "/static/template_images/royal.jpg",
#     """
#     <div style="background:#002147; color:white; text-align:center; padding:30px; font-family:Georgia;">
#       <h1 style="color:gold;">Wedding Celebration</h1>
#       <h2>{{bride_name}} ❤️ {{groom_name}}</h2>
#       <p>Invite you to share in their joy</p>
#       <p>Date: {{wedding_date}}</p>
#       <p>At: {{venue}}</p>
#       <img src="{{photo_url}}" style="width:140px; border-radius:10px; margin:20px;">
#       <p>{{message}}</p>
#     </div>
#     """
# ))

# # Template 2 - Floral Pink Elegance
# cursor.execute("""
# INSERT INTO invitation_templates (name, image_url, html_template)
# VALUES (?, ?, ?)
# """, (
#     "Floral Pink Elegance",
#     "/static/template_images/floral.jpg",
#     """
#     <div style="background:#fff0f5; color:#d6336c; text-align:center; padding:30px; font-family:'Brush Script MT', cursive;">
#       <h1>You're Invited</h1>
#       <h2>{{bride_name}} & {{groom_name}}</h2>
#       <p>Together with their families</p>
#       <p>Join us on {{wedding_date}} at {{venue}}</p>
#       <img src="{{photo_url}}" style="width:140px; border-radius:70px; margin:15px;">
#       <p>{{message}}</p>
#     </div>
#     """
# ))

# # Template 3 - Minimal Classic Black & White
# cursor.execute("""
# INSERT INTO invitation_templates (name, image_url, html_template)
# VALUES (?, ?, ?)
# """, (
#     "Minimal Classic",
#     "/static/template_images/minimal.jpg",
#     """
#     <div style="font-family:Cambria; color:#000; padding:40px; text-align:center; border:1px solid #000;">
#       <h1>Wedding Invitation</h1>
#       <p><strong>{{bride_name}}</strong> & <strong>{{groom_name}}</strong></p>
#       <p>cordially invite you to their wedding</p>
#       <p>on {{wedding_date}} at {{venue}}</p>
#       <img src="{{photo_url}}" style="width:100px; margin:20px;">
#       <p><em>{{message}}</em></p>
#     </div>
#     """
# ))

# conn.commit()
# conn.close()

# import sqlite3

# # 1. Connect to your SQLite database
# conn = sqlite3.connect('database.db')

# # 2. Create a cursor object
# cursor = conn.cursor()

# # 3. Execute a SELECT query to get only 'Tech' events that are not deleted (archived = 0)
# cursor.execute("SELECT * FROM events WHERE category = ? AND archived = 0", ('Art',))

# # 4. Fetch all results
# rows = cursor.fetchall()

# # 5. Print results
# for row in rows:
#     print(row)

# # 6. Close the connection
# conn.close()


# import sqlite3

# # 1. Connect to your SQLite database
# conn = sqlite3.connect('database.db')

# # 2. Create a cursor object
# cursor = conn.cursor()

# # 3. Define the list of event IDs to delete
# event_ids_to_delete = (3, 5, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18)

# # 4. Generate a placeholder string (?, ?, ?, ...) dynamically
# placeholders = ', '.join(['?'] * len(event_ids_to_delete))

# # 5. Execute the DELETE query
# cursor.execute(f"DELETE FROM events WHERE id IN ({placeholders})", event_ids_to_delete)

# # 6. Commit the changes
# conn.commit()

# # 7. Print how many rows were deleted
# print(f"{cursor.rowcount} events deleted.")

# # 8. Close the connection
# conn.close()




# import sqlite3

# # 1. Connect to your SQLite database
# conn = sqlite3.connect('database.db')

# # 2. Create a cursor object
# cursor = conn.cursor()

# # 3. List of event title and corresponding event_date
# updates = [
#     ('Modern Art Expo', '2025-08-13'),
#     ('Street Art Jam', '2025-05-24'),
#     ('diksha', '2025-05-30'),
#     ('Clay Modeling Masterclass', '2025-07-30'),
#     ('Art Battle Night', '2025-08-05'),
#     ('Mural Painting Day', '2025-07-15'),
#     ('Photography Basics', '2025-06-28'),
#     ('Origami & Paper Art Show', '2025-08-10'),
#     ('Calligraphy Day', '2025-07-09'),
#     ('Traditional Art Exhibit', '2025-09-07'),
#     ('3D Art Street Festival', '2025-09-13'),
#     ('Digital Illustration Meetup', '2025-07-13'),
#     ('Canvas Carnival', '2025-07-06'),
#     ('Sculpture Stories', '2025-07-13'),
#     ('Brushes & Brews', '2025-07-16'),
#     ('Graffiti Garden Jam', '2025-07-25'),
#     ('Portrait Power Workshop', '2025-07-30'),
#     ('Eco Art Installations', '2025-08-04'),
#     ('Monochrome Magic Exhibit', '2025-08-09'),
#     ('Interactive Light Art Show', '2025-08-13')
# ]

# # 4. Execute update for each event
# for title, event_date in updates:
#     cursor.execute("UPDATE events SET event_date = ? WHERE title = ?", (event_date, title))

# # 5. Commit changes
# conn.commit()

# # 6. Show success message
# print(f"{cursor.rowcount} event_date fields updated.")

# # 7. Close connection
# conn.close()


# PYTHON UPDATE

# import sqlite3

# # Connect to your database
# conn = sqlite3.connect('database.db')
# cursor = conn.cursor()

# # List of (title, event_date)
# fitness_updates = [
#     ('Zumba & Dance Fiesta', '2025-07-31'),
#     ('Yoga in the Park', '2025-07-01'),
#     ('HIIT Bootcamp', '2025-08-16'),
#     ('Cyclothon 2025', '2025-07-26'),
#     ('CrossFit Challenge', '2025-08-31'),
#     ('Mountain Hike & Fitness Trek', '2025-09-21'),
#     ('Aqua Aerobics Workshop', '2025-08-14'),
#     ('Pilates Pro Class', '2025-07-01'),
#     ('Kickboxing Training Camp', '2025-06-21'),
#     ('Sunrise Yoga by the Lake', '2025-07-09'),
#     ('Beach Bootcamp', '2025-08-04'),
#     ('Fitness Tech Expo', '2025-08-09'),
#     ('Glow-in-the-Dark Run', '2025-09-13'),
#     ('Breathe & Burn – Power Yoga', '2025-09-19'),
#     ('Fit & Fab Seniors Day', '2025-09-21'),
#     ('Jump & Jam Trampoline Fest', '2025-09-27'),
#     ('Urban Hike Challenge', '2025-09-29'),
#     ('Fit Mommies Workshop', '2025-10-03'),
#     ('Strength Games 2025', '2025-10-13')
# ]

# # Run the update query
# for title, event_date in fitness_updates:
#     cursor.execute("UPDATE events SET event_date = ? WHERE title = ?", (event_date, title))

# # Save changes and close
# conn.commit()
# print("Fitness event_date fields updated successfully.")
# conn.close()


# import sqlite3

# # 1. Connect to your database
# conn = sqlite3.connect('database.db')
# cursor = conn.cursor()

# # 2. List of event IDs
# event_ids = (118, 120, 3, 159, 158,156)

# # 3. Create placeholders dynamically
# placeholders = ','.join(['?'] * len(event_ids))

# # 4. Execute SELECT query
# query = f"SELECT id, title, start_date, end_date FROM events WHERE id IN ({placeholders})"
# cursor.execute(query, event_ids)

# # 5. Fetch and print results
# rows = cursor.fetchall()
# for row in rows:
#     print(f"ID: {row[0]}, Title: {row[1]}, Start Date: {row[2]}, End Date: {row[3]}")

# # 6. Close the connection
# conn.close()


# import sqlite3

# # 1. Connect to your SQLite database
# conn = sqlite3.connect('database.db')
# cursor = conn.cursor()

# # 2. Execute the query to find events with NULL event_date
# cursor.execute("""
#     SELECT id, title, start_date, end_date
#     FROM events
#     WHERE event_date IS NULL
# """)

# # 3. Fetch and display the results
# rows = cursor.fetchall()
# for row in rows:
#     print(f"ID: {row[0]}, Title: {row[1]}, Start Date: {row[2]}, End Date: {row[3]}")

# # 4. Close the database connection
# conn.close()


# import sqlite3

# # Connect to your database
# conn = sqlite3.connect('database.db')
# cursor = conn.cursor()

# # List of (id, event_date)
# updates = [
#     (87,  '2025-05-21'),
#     (101, '2025-06-01'),
#     (102, '2025-05-31'),
#     (106, '2025-05-31'),
#     (118, '2025-07-30'),
#     (120, '2025-07-15'),
#     (132, '2025-09-21'),
#     (156, '2025-07-30'),
#     (157, '2025-08-04'),
#     (158, '2025-08-09'),
#     (159, '2025-08-13'),
#     (164, '2025-09-19'),
#     (166, '2025-09-27'),
#     (169, '2025-10-13'),
#     (172, '2025-09-14'),
#     (176, '2025-09-27'),
#     (178, '2025-10-11'),
# ]

# # Execute update query for each
# for event_id, event_date in updates:
#     cursor.execute("UPDATE events SET event_date = ? WHERE id = ?", (event_date, event_id))

# # Commit changes
# conn.commit()
# print("✅ event_date updated for all listed events.")

# # Close connection
# conn.close()


# import sqlite3

# # Connect to database
# conn = sqlite3.connect('database.db')
# cursor = conn.cursor()

# # Query for non-deleted events
# cursor.execute("""
#     SELECT id, title, description,category
#     FROM events
#     WHERE is_deleted = 0 and category = "Tech"
# """)

# # Fetch and print results
# rows = cursor.fetchall()
# for row in rows:
#     print(f"ID: {row[0]}, Title: {row[1]}, Description: {row[2]}, category")

# # Close connection
# conn.close()

# import sqlite3

# # 1. Connect to your SQLite database
# conn = sqlite3.connect('database.db')

# # 2. Create a cursor object
# cursor = conn.cursor()

# # 3. Execute a SELECT query to get title, start_date, end_date for 'Art' events not archived
# cursor.execute("""
#     SELECT id,title, start_date, end_date 
#     FROM events 
#     WHERE category = ? AND archived = 0
# """, ('Fitness',))

# # 4. Fetch all results
# rows = cursor.fetchall()

# # 5. Print the event name with its start and end dates
# for row in rows:
#     print(f"id: {row[0]}, Title: {row[0]}, Start Date: {row[1]}, End Date: {row[2]}")

# # 6. Close the connection
# conn.close()


# import sqlite3

# # Connect to SQLite database
# conn = sqlite3.connect('database.db')
# cursor = conn.cursor()

# # Dictionary of event IDs and their updated descriptions
# updates = {
#     90: "India Folk Festival is a 6-hour celebration of India’s traditional dance, crafts, and cuisine. Experience folk music, puppet shows, and regional delicacies.",
#     136: "Kite Festival & Craft Fair features vibrant sky-high kites and handmade goods. Spend 5–6 hours enjoying workshops, stalls, and cultural performances.",
#     137: "Onam Cultural Show offers 4 hours of classical Kerala dance, boat race simulations, and Pookalam (floral designs) with traditional Onasadya meals.",
#     138: "Mela: Folk Food & Dance Fest brings a 6-hour village-style celebration with folk dances, open-air cooking, and local art across colorful stalls.",
#     139: "Street Theatre Showcase presents 3 hours of live, open-air drama from local troupes—highlighting social issues and regional folklore theatrics.",
#     140: "Navratri Garba Nights features 5 hours of traditional Gujarati dance, music, and colorful attire each night. Open to all skill levels with live dhol.",
#     141: "Classical Music Evenings offer 2.5 hours of soothing Hindustani and Carnatic recitals by renowned artists in an intimate, candle-lit setup.",
#     170: "Sufi Soul Evening is a 3-hour spiritual music event showcasing qawwalis and sufi poetry to stir the soul and connect with heritage.",
#     171: "Tribal Arts Showcase displays indigenous dances, crafts, and fashion. A 4-hour immersive session celebrating tribal culture and artistry.",
#     172: "Monsoon Dance Gala is a 4-hour live fusion of rain-themed performances across Bharatnatyam, Kathak, and contemporary styles.",
#     173: "Cultural Film Fest screens 4–5 hours of documentaries and short films capturing diverse cultural stories with panel discussions.",
#     174: "Artisans’ Village Fair is a 6-hour family event showcasing regional artisans with hands-on craft zones, storytelling, and street performances.",
#     175: "Rangoli & Folk Art Day involves 3.5 hours of traditional Indian floor art, painting demos, and regional folklore songs. Materials provided.",
#     176: "South India Cultural Night presents 4 hours of vibrant dance, temple music, and a culinary tour of Tamil, Telugu, and Kannada cultures.",
#     177: "Puppet Square, Udaipur hosts 3 hours of Rajasthani puppet theatre, storytelling, and workshops for families and kids in a heritage setting.",
#     178: "North East Culture Carnival includes 6 hours of cultural exchange with folk music, textile displays, and traditional delicacies from NE India.",
# }

# # Perform the update queries
# for event_id, description in updates.items():
#     cursor.execute("UPDATE events SET description = ? WHERE id = ?", (description, event_id))

# # Commit changes and close connection
# conn.commit()
# conn.close()

# print("Culture event descriptions updated successfully.")


# import sqlite3

# # Connect to SQLite database
# conn = sqlite3.connect('database.db')
# cursor = conn.cursor()

# # Event ID : Description (with duration in hours)
# updates = {
#     127: "Zumba & Dance Fiesta is a 2-hour high-energy dance workout event mixing Latin rhythms and cardio. Perfect for all fitness levels to groove and sweat.",
#     128: "Yoga in the Park offers a peaceful 90-minute Hatha yoga session amid nature. Ideal for all ages and skill levels to enhance flexibility and calmness.",
#     129: "HIIT Bootcamp delivers 2 hours of intense interval training focused on strength and endurance. Expect burpees, circuits, and major sweat.",
#     130: "Cyclothon 2025 is a 3-hour cycling event through city routes promoting fitness and eco-friendly transport. Includes hydration stops and safety guides.",
#     131: "CrossFit Challenge is a full-body 2.5-hour workout focused on powerlifting, speed drills, and functional movements. For intermediate to advanced fitness enthusiasts.",
#     132: "Mountain Hike & Fitness Trek is a 6-hour guided trek combining endurance training and scenic exploration. Includes fitness challenges along the trail.",
#     133: "Aqua Aerobics Workshop is a 2-hour pool-based fitness session ideal for low-impact strength and cardio. Suitable for all age groups.",
#     134: "Pilates Pro Class offers a 90-minute core-strengthening workout focusing on posture, control, and flexibility using floor mats and light resistance.",
#     135: "Kickboxing Training Camp includes a 2-hour session covering punches, kicks, and cardio drills. A great stress reliever and full-body fitness builder.",
#     160: "Sunrise Yoga by the Lake is a 75-minute session at dawn combining breathing, flow, and meditation for a serene start to the day.",
#     161: "Beach Bootcamp is a 2-hour high-intensity fitness class on sand featuring resistance bands, sprint drills, and bodyweight workouts.",
#     162: "Fitness Tech Expo spans 6 hours showcasing the latest in wearables, smart gear, and AI-based workout tech. Includes demos and expert panels.",
#     163: "Glow-in-the-Dark Run is a 3-hour night run event with neon accessories, music, and LED trails. A fun cardio event for all ages.",
#     164: "Breathe & Burn – Power Yoga combines breathwork with intense flow sequences over a 2-hour class designed to build heat and endurance.",
#     165: "Fit & Fab Seniors Day is a 4-hour wellness day with light workouts, nutrition talks, and fun games for participants aged 50 and above.",
#     166: "Jump & Jam Trampoline Fest offers 2 hours of fitness fun with jump routines, aerobics, and core training on professional trampolines.",
#     167: "Urban Hike Challenge is a 3-hour city trek with stair climbs, fast-paced walking, and historic trail challenges. Great for stamina and sightseeing.",
#     168: "Fit Mommies Workshop is a 2-hour fitness and nutrition workshop tailored for new moms. Includes stroller workouts and safe core training.",
#     169: "Strength Games 2025 features 5 hours of competitive fitness games including deadlifts, tire flips, and team challenges for strength athletes.",
# }

# # Execute update queries
# for event_id, description in updates.items():
#     cursor.execute("UPDATE events SET description = ? WHERE id = ?", (description, event_id))

# # Commit changes and close connection
# conn.commit()
# conn.close()

# print("Fitness event descriptions updated successfully.")


# import sqlite3

# # 1. Connect to your SQLite database
# conn = sqlite3.connect('database.db')

# # 2. Create a cursor object
# cursor = conn.cursor()

# # 3. Execute a SELECT query to get only 'Tech' events that are not deleted (archived = 0)
# cursor.execute("SELECT * FROM users")

# # 4. Fetch all results
# rows = cursor.fetchall()

# # 5. Print results
# for row in rows:
#     print(row)

# # 6. Close the connection
# conn.close()
# 
# import sqlite3
# from werkzeug.security import generate_password_hash

# # Set your new password here
# new_password = "admin123"  # CHANGE THIS
# hashed_password = generate_password_hash(new_password)

# Connect to your SQLite database
# conn = sqlite3.connect('database.db')
# cursor = conn.cursor()

# Check if admin exists
# cursor.execute("ALTER TABLE bookings ADD COLUMN original_ticket_quantity INTEGER;")
# admin_user = cursor.fetchone()

# if admin_user:
#     # Update the password
#     cursor.execute("UPDATE users SET password = ? WHERE username = ?", (hashed_password, 'admin'))
#     conn.commit()
#     print("✅ Admin password updated successfully.")
# else:
#     print("❌ Admin user not found. Make sure a user with username 'admin' exists.")

# # Close the connection
# conn.close
import sqlite3

conn = sqlite3.connect("database.db")
cursor = conn.cursor()

cursor.execute("""
    UPDATE bookings
    SET original_ticket_quantity = ticket_quantity
    WHERE original_ticket_quantity IS NULL
""")
conn.commit()
conn.close()

