import sqlite3

conn = sqlite3.connect('database.db')
cursor = conn.cursor()

# USERS table
cursor.execute('''
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL
)
''')

# EVENTS table
cursor.execute('''
CREATE TABLE IF NOT EXISTS events (
   id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    category TEXT NOT NULL,
    description TEXT NOT NULL,
    date TEXT NOT NULL,
    location TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
''')

# BOOKINGS table with full info
cursor.execute('''
CREATE TABLE IF NOT EXISTS bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    event_id INTEGER,
    booking_date TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id),
    FOREIGN KEY(event_id) REFERENCES events(id)
)
''')

# Insert sample events
cursor.execute("INSERT INTO events (title, category, start_date, end_date, location) VALUES (?, ?, ?, ?, ?)",
               ('Tech Conference', 'Tech Conference', '2025-05-10', '2025-05-12', 'New York'))

cursor.execute("INSERT INTO events (title, category, start_date, end_date, location) VALUES (?, ?, ?, ?, ?)",
               ('Art Festival', 'Art & Culture Fest', '2025-06-15', '2025-06-18', 'Los Angeles'))

conn.commit()
conn.close()

print("Database setup complete ✅")
