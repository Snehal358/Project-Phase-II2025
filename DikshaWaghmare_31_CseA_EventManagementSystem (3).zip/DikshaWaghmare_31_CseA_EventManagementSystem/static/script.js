// script.js

let events = JSON.parse(localStorage.getItem('events')) || [
    {
      id: 1,
      title: "Tech Conference 2025",
      date: "2025-05-15",
      location: "New Delhi",
      description: "A conference for technology professionals."
    },
    {
      id: 2,
      title: "Art & Culture Fest",
      date: "2025-06-10",
      location: "Mumbai",
      description: "Celebrate art, food, and culture."
    }
  ];
  
  function renderEvents() {
    const container = document.getElementById('events-container');
    if (!container) return;
  
    container.innerHTML = '';
    events.forEach(event => {
      const div = document.createElement('div');
      div.className = "event-card";
      div.innerHTML = `
        <h3>${event.title}</h3>
        <p><strong>Date:</strong> ${event.date}</p>
        <p><strong>Location:</strong> ${event.location}</p>
        <p>${event.description}</p>
        <a class="button" href="event-details.html?id=${event.id}">View Details</a>
      `;
      container.appendChild(div);
    });
  }
  
  function renderEventDetails() {
    const params = new URLSearchParams(window.location.search);
    const eventId = parseInt(params.get("id"));
    const event = events.find(e => e.id === eventId);
    if (!event) return;
  
    document.getElementById('title').innerText = event.title;
    document.getElementById('date').innerText = event.date;
    document.getElementById('location').innerText = event.location;
    document.getElementById('description').innerText = event.description;
  }
  
  function handleAdminForm() {
    const form = document.getElementById('create-event-form');
    if (!form) return;
  
    form.addEventListener('submit', function (e) {
      e.preventDefault();
  
      const newEvent = {
        id: Date.now(),
        title: document.getElementById('titleInput').value,
        date: document.getElementById('dateInput').value,
        location: document.getElementById('locationInput').value,
        description: document.getElementById('descriptionInput').value
      };
  
      events.push(newEvent);
      localStorage.setItem('events', JSON.stringify(events));
      alert("Event created successfully!");
      form.reset();
    });
  }
  
  // Auto-run on load
  renderEvents();
  renderEventDetails();
  handleAdminForm();

  







  function handleForgotPassword() {
    const email = document.getElementById('email').value;
  
    if (!email) {
      alert('Please enter your email address to reset password.');
      return;
    }
  
    firebase.auth().sendPasswordResetEmail(email)
      .then(() => {
        alert('Password reset email sent. Please check your inbox.');
      })
      .catch(error => {
        alert('Error: ' + error.message);
      });
  }

  













  
