# Smart Event Management System

The **Smart Event Management System** is a dynamic, responsive, and full-stack web application built using **Flask**, **SQLite**, **HTML**, **CSS**, and **JavaScript**. Designed to simplify the process of planning and managing events, the system provides customized features for both general users and administrators, all while delivering a seamless user experience across devices.

## 🌟 Key Features

### 👥 General User Features
- **User Registration & Login**: Secure and intuitive authentication system.
- **Event Browsing**: Explore a wide range of event types such as:
  - Cultural Festivals
  - Technology Conferences
  - Fitness Workshops
  - Weddings
- **Special Wedding Module**:
  - Choose custom themes
  - Specify guest count
  - Select decoration styles
  - Manage additional wedding details from one unified interface
- **Responsive UI**: Fully functional across desktop and mobile devices.
- **Real-time Input Validation**: Enhances data accuracy during form submissions.

### 🛠️ Admin Features
- **Admin Dashboard**: Secure and comprehensive with role-based access control.
- **Event Management**: Create, update, or delete events.
- **User Management**: View and manage registered users and their bookings.
- **Platform Monitoring**: Track and oversee all user activities and event operations.
- **Feedback System**: Review user feedback to improve services and features.

## 🧱 Tech Stack

| Layer        | Technology             |
|--------------|------------------------|
| Frontend     | HTML, CSS, JavaScript  |
| Backend      | Flask (Python)         |
| Database     | SQLite (Relational DB) |
| Templating   | Jinja2 (via Flask)     |
| Validation   | JavaScript + Flask WTForms (optional) |
| Hosting      | (to be added if deployed) |

## 🗃️ Database Schema (Basic Overview)

- **Users Table**: Stores user credentials and profiles
- **Events Table**: Stores event details like title, type, date, etc.
- **Bookings Table**: Tracks user bookings and selections
- **Admin Table**: Stores admin credentials and access roles
- **Feedback Table**: Collects user feedback and suggestions

## 🚀 Installation and Setup

### 1. Clone the Repository
```bash
git clone https://github.com/your-username/smart-event-management.git
cd smart-event-management
