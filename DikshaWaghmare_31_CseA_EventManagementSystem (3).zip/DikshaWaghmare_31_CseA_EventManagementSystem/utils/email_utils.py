import sqlite3
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from flask_apscheduler import APScheduler
from reportlab.lib.pagesizes import A4, letter
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
from reportlab.lib.utils import ImageReader
from email.mime.application import MIMEApplication
import os
from datetime import datetime



def get_wedding_booking_by_id(booking_id):
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM wedding_bookings WHERE id = ?", (booking_id,))
    booking = cursor.fetchone()
    conn.close()
    return dict(booking) if booking else None

def get_guests_for_booking(booking_id):
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM wedding_guests WHERE booking_id = ?", (booking_id,))
    guests = cursor.fetchall()
    conn.close()
    return [dict(guest) for guest in guests]






def send_email(recipient, subject, body, attachment_path=None):
    sender_email = "diksaraswati5@gmail.com"
    sender_password = "emej zljq gual vhme"

    try:
        msg = MIMEMultipart()
        msg['From'] = sender_email
        msg['To'] = recipient
        msg['Subject'] = subject

        msg.attach(MIMEText(body, 'plain', _charset='utf-8'))

        if attachment_path:
            with open(attachment_path, 'rb') as f:
                part = MIMEApplication(f.read(), Name=os.path.basename(attachment_path))
                part['Content-Disposition'] = f'attachment; filename="{os.path.basename(attachment_path)}"'
                msg.attach(part)

        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as server:
            server.login(sender_email, sender_password)
            server.sendmail(sender_email, recipient, msg.as_string())

        print(f"✅ Email sent to {recipient}")

    except Exception as e:
        print(f"❌ Failed to send email to {recipient}: {e}")

def send_reset_email(email, reset_url):
    subject = "Reset Your Password - Event Management"
    body = f"""Hi,

We received a request to reset your password for your event Management account.

Please click the link below to reset your password:
{reset_url}

If you did not request this, please ignore this email.

Warm regards,  
Event Management Team
"""
    send_email(email, subject, body)


def generate_wedding_plan_pdf(booking_data):
    # Define the output path
    pdf_filename = f"wedding_plan_booking_{booking_data['id']}.pdf"
    pdf_path = os.path.join("static", "pdfs", pdf_filename)

    # Ensure folder exists
    os.makedirs(os.path.dirname(pdf_path), exist_ok=True)

    # Start canvas
    c = canvas.Canvas(pdf_path, pagesize=A4)
    width, height = A4

    y = height - inch

    # Title
    c.setFont("Helvetica-Bold", 18)
    c.drawString(1 * inch, y, "Wedding Plan Summary")
    y -= 0.4 * inch

    # Basic Info
    c.setFont("Helvetica", 12)
    c.drawString(1 * inch, y, f"Bride: {booking_data['bride_name']}")
    y -= 0.2 * inch
    c.drawString(1 * inch, y, f"Groom: {booking_data['groom_name']}")
    y -= 0.2 * inch
    c.drawString(1 * inch, y, f"Theme: {booking_data['theme_name']}")
    y -= 0.2 * inch
    c.drawString(1 * inch, y, f"Venue: {booking_data['venue']}")
    y -= 0.2 * inch
    c.drawString(1 * inch, y, f"Guest Count: {booking_data['guest_count']}")
    y -= 0.2 * inch
    c.drawString(1 * inch, y, f"Wedding Date: {booking_data['booking_date']}")
    y -= 0.2 * inch
    c.drawString(1 * inch, y, f"Total Price: ₹{booking_data['total_price']}")
    y -= 0.2 * inch

    if booking_data.get("notes"):
        y -= 0.1 * inch
        c.drawString(1 * inch, y, f"Notes: {booking_data['notes']}")
        y -= 0.3 * inch

    # Events
    c.setFont("Helvetica-Bold", 14)
    c.drawString(1 * inch, y, "Event Breakdown")
    y -= 0.3 * inch

    c.setFont("Helvetica", 12)
    for event in booking_data['events']:
        if y < 1 * inch:
            c.showPage()
            y = height - inch
        c.drawString(1.1 * inch, y, f"- {event['name'].title()}:")
        y -= 0.2 * inch
        c.drawString(1.3 * inch, y, f"  Decoration: {event.get('decoration_vendor', 'N/A')}")
        y -= 0.2 * inch
        c.drawString(1.3 * inch, y, f"  Catering: {event.get('catering_vendor', 'N/A')}")
        y -= 0.2 * inch
        c.drawString(1.3 * inch, y, f"  Makeup: {event.get('makeup_vendor', 'N/A')}")
        y -= 0.2 * inch
        c.drawString(1.3 * inch, y, f"  Photography: {event.get('photography_vendor', 'N/A')}")
        y -= 0.2 * inch
        c.drawString(1.3 * inch, y, f"  Staff Count: {event.get('staff_count', 'N/A')}")
        y -= 0.3 * inch

    # Footer
    c.setFont("Helvetica-Oblique", 10)
    c.drawString(1 * inch, 0.7 * inch, f"Generated on {datetime.now().strftime('%Y-%m-%d %H:%M')}")

    c.save()
    return pdf_path


def send_ticket_cancel_email(recipient, username, event_title, cancelled, remaining, full_cancel=False):
    subject = f"Event Booking Cancellation - {event_title}"
    if full_cancel:
        status_line = "Your booking has been fully canceled."
    else:
        status_line = f"You have canceled {cancelled} ticket(s). {remaining} ticket(s) remain."

    body = f"""Hello {username},

This is to confirm that your ticket cancellation for the event "{event_title}" has been processed.

Details:
- Event: {event_title}
- Cancelled Tickets: {cancelled}
- Remaining Tickets: {remaining}
- Status: {"Fully Cancelled" if full_cancel else "Partially Cancelled"}

{status_line}

Thank you,
Event Management Team
"""

    send_email(recipient, subject, body)
