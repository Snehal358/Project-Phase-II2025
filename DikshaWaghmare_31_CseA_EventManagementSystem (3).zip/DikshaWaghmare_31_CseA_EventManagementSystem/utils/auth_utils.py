import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
from itsdangerous import URLSafeTimedSerializer

# Config
SECRET_KEY = 'your-strong-secret-key-here'
SECURITY_PASSWORD_SALT = 'your-random-salt-here'
DATABASE = 'database.db'

serializer = URLSafeTimedSerializer(SECRET_KEY)

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def get_user_by_email(email):
    db = get_db()
    return db.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()

def hash_password(password):
    return generate_password_hash(password)  # Uses scrypt, PBKDF2, etc.


def verify_password(stored_hash, input_password):
    result = check_password_hash(stored_hash, input_password)

    # Debug prints
    print("🔐 [DEBUG] Password entered by user:", input_password)
    print("📦 [DEBUG] Stored password hash:     ", stored_hash)
    print("✅ [DEBUG] Password match result:     ", result)

    return result


def update_user_password(user_id, new_password):
    conn = get_db()
    hashed_password = hash_password(new_password)
    conn.execute("UPDATE users SET password = ? WHERE id = ?", (hashed_password, user_id))
    conn.commit()
    conn.close()

def generate_reset_token(user_id):
    return serializer.dumps(user_id, salt=SECURITY_PASSWORD_SALT)

def verify_token(token, expiration=3600):
    try:
        return serializer.loads(token, salt=SECURITY_PASSWORD_SALT, max_age=expiration)
    except Exception:
        return None
